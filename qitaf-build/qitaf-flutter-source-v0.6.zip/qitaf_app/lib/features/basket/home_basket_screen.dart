import 'package:flutter/material.dart';
import '../../core/models/basket_plan.dart';
import '../../core/models/product.dart';
import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../core/services/read_aloud.dart';
import '../../widgets/common_widgets.dart';
import '../checkout/checkout_flow.dart';

void openHomeBasket(BuildContext context) => Navigator.of(context)
    .push(MaterialPageRoute<void>(builder: (_) => const HomeBasketScreen()));

class HomeBasketBanner extends StatelessWidget {
  const HomeBasketBanner({super.key});
  @override
  Widget build(BuildContext context) => Material(
        color: QitafColors.burgundy,
        borderRadius: BorderRadius.circular(26),
        child: InkWell(
          key: const ValueKey('open-home-basket'),
          onTap: () => openHomeBasket(context),
          borderRadius: BorderRadius.circular(26),
          child: const Padding(
              padding: EdgeInsets.all(18),
              child: Row(children: [
                Icon(Icons.shopping_basket_rounded,
                    size: 46, color: QitafColors.ivory),
                SizedBox(width: 14),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text('جديد قِطاف',
                          style: TextStyle(
                              color: Color(0xFFFFDA8A),
                              fontSize: 12,
                              fontWeight: FontWeight.bold)),
                      Text('سلة البيت',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.w900)),
                      Text('على قدّ ميزانيتك، لك أو لأهلك',
                          style: TextStyle(color: Colors.white, fontSize: 13)),
                    ])),
                Icon(Icons.arrow_back_rounded, color: Colors.white),
              ])),
        ),
      );
}

class HomeBasketScreen extends StatefulWidget {
  const HomeBasketScreen({super.key});
  @override
  State<HomeBasketScreen> createState() => _HomeBasketScreenState();
}

class _HomeBasketScreenState extends State<HomeBasketScreen> {
  int _budget = 10000;
  int _people = 4;
  BasketPurpose _purpose = BasketPurpose.home;
  List<CartItem> _rows = [];
  bool _initialized = false;
  bool _submitted = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      _initialized = true;
      _suggest();
    }
  }

  void _suggest() {
    _rows = suggestBasket(
        products: demoProducts,
        currentCart: AppScope.of(context).cart,
        budgetRiyals: _budget,
        people: _people,
        purpose: _purpose,
        deliveryRiyals: AppStore.deliveryRiyals);
  }

  void _refresh(VoidCallback change) {
    setState(() {
      change();
      _suggest();
    });
  }

  int get _proposedMinor =>
      _rows.fold(0, (n, r) => n + (r.total * 100).round());
  int _totalMinor(AppStore store) =>
      store.subtotalMinor +
      _proposedMinor +
      (_rows.isEmpty && store.cart.isEmpty ? 0 : AppStore.deliveryRiyals * 100);
  void _message(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  void _changeQuantity(CartItem row, int delta) {
    final store = AppScope.of(context);
    if (delta > 0) {
      final units = store.reservedUnits(row.product.id) +
          row.selection.weight.quantityInBaseUnits *
              (row.selection.quantity + 1);
      if (units > row.product.stock) {
        _message('وصلت إلى الكمية المتاحة من هذا المحصول.');
        return;
      }
      final addedMinor = (row.selection.unitTotal(row.product) * 100).round();
      if (_totalMinor(store) + addedMinor > _budget * 100) {
        _message(
            'هذه الزيادة تتجاوز الميزانية مع التوصيل. ارفع الميزانية أو قلّل منتجًا آخر.');
        return;
      }
    }
    setState(() {
      if (row.selection.quantity + delta <= 0) {
        _rows.remove(row);
      } else {
        row.selection =
            row.selection.copyWith(quantity: row.selection.quantity + delta);
      }
    });
  }

  Future<void> _customBudget() async {
    final controller = TextEditingController(text: '$_budget');
    final value = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('كم ميزانيتك بالريال اليمني؟'),
              content: TextField(
                  controller: controller,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      helperText: 'تشمل سلتك الحالية والتوصيل التقديري')),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('إلغاء')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, controller.text),
                    child: const Text('اعتماد'))
              ],
            ));
    // The dialog may still be animating out; defer disposal past that transition.
    await Future<void>.delayed(const Duration(milliseconds: 300));
    controller.dispose();
    if (!mounted || value == null) return;
    final parsed = parseBudget(value);
    if (parsed == null) {
      _message('أدخل مبلغًا صحيحًا بين 1 و1٬000٬000 ريال.');
      return;
    }
    _refresh(() => _budget = parsed);
  }

  void _submit({required bool checkout}) {
    if (_submitted || _rows.isEmpty) return;
    final store = AppScope.of(context);
    if (!store.addBundle(_rows, budgetRiyals: _budget)) {
      _message(store.lastCartError ?? 'تعذر إضافة السلة.');
      return;
    }
    setState(() => _submitted = true);
    if (checkout) {
      Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
          builder: (_) => RecipientAddressScreen(
              forSomeoneElse: _purpose == BasketPurpose.gift)));
    } else {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أُضيفت سلة البيت. تجدها في «سلتي».')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final totalMinor = _totalMinor(store);
    final remaining = (_budget * 100 - totalMinor) / 100;
    final valid = _rows.isNotEmpty && remaining >= 0 && !_submitted;
    final summary =
        'هذه أسعار تجريبية وليست طلبًا حقيقيًا. ميزانيتك $_budget ريال يمني. '
        '${_rows.map((r) => '${r.product.name}، عدد ${r.selection.quantity} بوزن ${r.selection.weight.label}، بقيمة ${formatMoney(r.total)} ريال').join('. ')}. '
        'سلتك السابقة ${formatMoney(store.subtotal)} ريال. '
        'التوصيل التقديري ${AppStore.deliveryRiyals} ريال. الإجمالي ${formatMoney(totalMinor / 100)} ريال.';
    return Scaffold(
      appBar: AppBar(title: const Text('سلة البيت'), actions: [
        IconButton(
            tooltip: 'كيف تعمل؟',
            onPressed: () => showDialog<void>(
                context: context,
                builder: (ctx) => AlertDialog(
                      title: const Text('نرتّب القطفة على قدّك'),
                      content: const Text(
                          'اختر ميزانية تشمل التوصيل. نقترح كميات من المنتجات التجريبية المتاحة، ثم تعدّلها بنفسك. عدد الأشخاص يساعد في اقتراح الكمية، وليس ضمانًا لاكتفاء الأسرة أو اشتراكًا تلقائيًا. لا يُدفع أي مبلغ في هذه النسخة.'),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: const Text('فهمت'))
                      ],
                    )),
            icon: const Icon(Icons.help_outline_rounded)),
      ]),
      body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [
                      QitafColors.burgundy,
                      QitafColors.burgundyDark
                    ]),
                    borderRadius: BorderRadius.circular(28)),
                child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.shopping_basket_rounded,
                          color: Color(0xFFFFDA8A), size: 40),
                      SizedBox(height: 10),
                      Text('خير المزرعة،\nعلى قدّ ميزانيتك.',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 27,
                              height: 1.3)),
                      SizedBox(height: 8),
                      Text('تختار المبلغ • تعدّل القطفة • تحدد المستلم',
                          style: TextStyle(color: Colors.white, fontSize: 13)),
                    ])),
            const SizedBox(height: 12),
            const Text(
                'نسخة تجريبية • الأسعار والمزارع والتوصيل أمثلة وليست عروضًا حقيقية.',
                style: TextStyle(
                    color: QitafColors.muted, fontSize: 12, height: 1.5)),
            const SizedBox(height: 22),
            _heading('١', 'سلة للبيت أم هدية؟'),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                  child: _mode(BasketPurpose.home, Icons.home_rounded,
                      'للبيت والعائلة', 'خضار وفاكهة')),
              const SizedBox(width: 10),
              Expanded(
                  child: _mode(BasketPurpose.gift, Icons.card_giftcard_rounded,
                      'مختارات وهدايا', 'بن وعسل')),
            ]),
            const SizedBox(height: 22),
            _heading('٢', 'حدّد ميزانيتك'),
            const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                    'اختر مبلغًا سريعًا أو «مبلغ آخر» • يشمل الإجمالي سلتك الحالية والتوصيل التقديري • يمكنك تعديل الكميات قبل الإضافة ولا يوجد شراء تلقائي',
                    style: TextStyle(color: QitafColors.muted, fontSize: 13))),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final value in [3000, 5000, 10000, 20000])
                ChoiceChip(
                  label: Text('${formatMoney(value)} ر.ي'),
                  selected: _budget == value,
                  onSelected: (_) => _refresh(() => _budget = value),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                  selectedColor: QitafColors.sand,
                ),
              ActionChip(
                  avatar: const Icon(Icons.edit_outlined, size: 19),
                  label: Text([3000, 5000, 10000, 20000].contains(_budget)
                      ? 'مبلغ آخر'
                      : '${formatMoney(_budget)} ر.ي'),
                  onPressed: _customBudget,
                  padding: const EdgeInsets.symmetric(vertical: 10)),
            ]),
            if (_purpose == BasketPurpose.home) ...[
              const SizedBox(height: 16),
              Row(children: [
                const Expanded(
                    child: Text('لِكم شخصًا؟',
                        style: TextStyle(fontWeight: FontWeight.w800))),
                for (final count in [2, 4, 6])
                  Padding(
                      padding: const EdgeInsetsDirectional.only(start: 6),
                      child: ChoiceChip(
                          label: Text('$count'),
                          selected: _people == count,
                          onSelected: (_) => _refresh(() => _people = count),
                          padding: const EdgeInsets.all(10),
                          selectedColor: QitafColors.sand))
              ]),
              const Text('الكميات اقتراح قابل للتعديل، وليست خطة غذائية.',
                  style: TextStyle(color: QitafColors.muted, fontSize: 11)),
            ],
            const SizedBox(height: 22),
            Row(children: [
              Expanded(child: _heading('٣', 'قطفتك المقترحة')),
              TextButton(
                  onPressed: () => _refresh(() {}),
                  child: const Text('اقتراح جديد'))
            ]),
            const SizedBox(height: 10),
            if (_rows.isEmpty)
              Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20)),
                  child: const Text(
                      'لا تكفي الميزانية المتبقية لمنتج مناسب مع التوصيل، أو نفدت الكمية. ارفع المبلغ أو قلّل سلتك الحالية.')),
            for (final row in _rows) _line(row),
            const SizedBox(height: 14),
            ReadAloudButton(text: summary),
            const SizedBox(height: 8),
            const Text('القراءة الصوتية تحتاج صوتًا عربيًا متاحًا على جهازك.',
                textAlign: TextAlign.center,
                style: TextStyle(color: QitafColors.muted, fontSize: 11)),
            const SizedBox(height: 20),
            Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22)),
                child: Column(children: [
                  if (store.cart.isNotEmpty)
                    _amount('سلتك الحالية', store.subtotal),
                  _amount('القطفة المقترحة', _proposedMinor / 100),
                  _amount('توصيل تقديري',
                      totalMinor == 0 ? 0 : AppStore.deliveryRiyals.toDouble()),
                  const Divider(height: 24),
                  _amount('الإجمالي بعد الإضافة', totalMinor / 100,
                      strong: true),
                  const SizedBox(height: 10),
                  Text(
                      remaining >= 0
                          ? 'يبقى من ميزانيتك ${formatMoney(remaining)} ريال'
                          : 'تجاوزت ميزانيتك ${formatMoney(-remaining)} ريال',
                      key: const ValueKey('remaining-budget'),
                      style: TextStyle(
                          color: remaining >= 0
                              ? QitafColors.terraceGreen
                              : QitafColors.burgundy,
                          fontWeight: FontWeight.w800)),
                ])),
            if (store.storageWarning != null)
              Padding(
                  padding: const EdgeInsets.all(10),
                  child: Text(store.storageWarning!)),
          ]),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 6),
        decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 16)]),
        child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              FilledButton.icon(
                  key: const ValueKey('basket-checkout'),
                  onPressed: valid ? () => _submit(checkout: true) : null,
                  icon: Icon(_purpose == BasketPurpose.gift
                      ? Icons.card_giftcard_rounded
                      : Icons.location_on_outlined),
                  label: Text(_purpose == BasketPurpose.gift
                      ? 'أضف السلة وحدّد المستلم'
                      : 'أضف السلة وانتقل للعنوان')),
              TextButton(
                  key: const ValueKey('basket-add-only'),
                  onPressed: valid ? () => _submit(checkout: false) : null,
                  child: const Text('أضف إلى سلتي فقط')),
            ])),
      ),
    );
  }

  Widget _mode(BasketPurpose purpose, IconData icon, String label,
          String subtitle) =>
      Material(
        color: _purpose == purpose ? const Color(0xFFE6F0E9) : Colors.white,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => _refresh(() => _purpose = purpose),
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  Icon(icon,
                      color: _purpose == purpose
                          ? QitafColors.terraceGreen
                          : QitafColors.muted,
                      size: 32),
                  const SizedBox(height: 8),
                  Text(label,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w900)),
                  Text(subtitle,
                      style: const TextStyle(
                          color: QitafColors.muted, fontSize: 12)),
                  if (_purpose == purpose)
                    const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Icon(Icons.check_circle_rounded,
                            size: 19, color: QitafColors.terraceGreen)),
                ]))),
      );
  Widget _heading(String number, String title) => Row(children: [
        CircleAvatar(
            radius: 15,
            backgroundColor: QitafColors.sand,
            child: Text(number,
                style: const TextStyle(
                    color: QitafColors.burgundy, fontWeight: FontWeight.bold))),
        const SizedBox(width: 10),
        Flexible(
            child: Text(title,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900))),
      ]);
  Widget _line(CartItem row) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(22)),
      child: Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(row.product.productAsset,
                  width: 70, height: 80, fit: BoxFit.cover)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(row.product.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16)),
                Text(
                    '${row.selection.weight.label} × ${row.selection.quantity}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                Text(
                    '${row.selection.quality.label} · ${row.selection.ripeness.label}',
                    style: const TextStyle(
                        fontSize: 12, color: QitafColors.muted)),
                Text(row.product.location,
                    style: const TextStyle(
                        fontSize: 11, color: QitafColors.muted)),
              ])),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          IconButton(
              tooltip: 'تقليل ${row.product.name}',
              onPressed: () => _changeQuantity(row, -1),
              icon: const Icon(Icons.remove_circle_outline_rounded)),
          Text('${row.selection.quantity}',
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          IconButton(
              tooltip: 'زيادة ${row.product.name}',
              onPressed: () => _changeQuantity(row, 1),
              icon: const Icon(Icons.add_circle_rounded,
                  color: QitafColors.burgundy)),
          const Spacer(),
          Text('${formatMoney(row.total)} ر.ي',
              style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  color: QitafColors.burgundy,
                  fontSize: 17)),
        ]),
      ]));
  Widget _amount(String label, double amount, {bool strong = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        Expanded(
            child: Text(label,
                style: TextStyle(
                    fontSize: strong ? 16 : 13,
                    fontWeight: strong ? FontWeight.w900 : FontWeight.normal))),
        Text('${formatMoney(amount)} ر.ي',
            style: TextStyle(
                fontSize: strong ? 21 : 14,
                fontWeight: FontWeight.w900,
                color: strong ? QitafColors.burgundy : QitafColors.charcoal)),
      ]));
}
