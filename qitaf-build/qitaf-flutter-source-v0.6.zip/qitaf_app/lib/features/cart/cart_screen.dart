import 'package:flutter/material.dart';
import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';
import '../checkout/checkout_flow.dart';
import '../basket/home_basket_screen.dart';
import '../../core/services/read_aloud.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key, this.onBrowse});

  final VoidCallback? onBrowse;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return SafeArea(
      child: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (store.cart.isEmpty) {
            return EmptyState(
              icon: Icons.shopping_basket_outlined,
              title: 'سلتك تنتظر أول قطفة',
              message:
                  'اضغط على بطاقة أي منتج داخل البث، واختر الوزن والكمية ثم أضفه إلى السلة.',
              action: SizedBox(
                width: 190,
                child: FilledButton(
                    onPressed: () => openHomeBasket(context),
                    child: const Text('جهّز سلة البيت')),
              ),
            );
          }

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
                child: Row(
                  children: [
                    const Expanded(
                        child: SectionTitle(
                            title: 'سلتي',
                            subtitle: 'راجع الكميات قبل تحديد عنوان المستلم')),
                    TextButton.icon(
                      onPressed: store.clearCart,
                      icon: const Icon(Icons.delete_outline_rounded),
                      label: const Text('إفراغ'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 18),
                  itemCount: store.cart.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final item = store.cart[index];
                    return Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(22)),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(17),
                            child: Image.asset(item.product.productAsset,
                                width: 92, height: 105, fit: BoxFit.cover),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                        child: Text(item.product.name,
                                            style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w900))),
                                    IconButton(
                                      onPressed: () => store.remove(item),
                                      visualDensity: VisualDensity.compact,
                                      icon: const Icon(Icons.close_rounded,
                                          color: QitafColors.muted),
                                    ),
                                  ],
                                ),
                                Text(
                                  '${item.selection.weight.label} · ${item.selection.quality.label}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: QitafColors.muted, fontSize: 12),
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  children: [
                                    QuantityStepper(
                                      compact: true,
                                      value: item.selection.quantity,
                                      onMinus: () => store.decrement(item),
                                      onPlus: () {
                                        if (!store.increment(item))
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                                  content: Text(
                                                      store.lastCartError ??
                                                          'نفدت الكمية.')));
                                      },
                                    ),
                                    const Spacer(),
                                    Text(
                                      '${formatMoney(item.total)} ر.ي',
                                      style: const TextStyle(
                                          color: QitafColors.burgundy,
                                          fontWeight: FontWeight.w900,
                                          fontSize: 16),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 24,
                        offset: Offset(0, -8))
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Column(
                    children: [
                      _summaryRow('المحاصيل', store.subtotal),
                      const SizedBox(height: 7),
                      _summaryRow('توصيل تقديري', store.deliveryFee),
                      const Divider(height: 24),
                      Row(
                        children: [
                          const Text('الإجمالي',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w900)),
                          const Spacer(),
                          Text(
                            '${formatMoney(store.total)} ريال',
                            style: const TextStyle(
                                fontSize: 22,
                                color: QitafColors.burgundy,
                                fontWeight: FontWeight.w900),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      ReadAloudButton(
                          text:
                              'هذه سلة تجريبية. مجموع المحاصيل ${formatMoney(store.subtotal)} ريال. التوصيل التقديري ${formatMoney(store.deliveryFee)} ريال. الإجمالي ${formatMoney(store.total)} ريال.'),
                      const SizedBox(height: 8),
                      FilledButton.icon(
                        onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) =>
                                    const RecipientAddressScreen())),
                        icon: const Icon(Icons.location_on_outlined),
                        label: const Text('اختيار المستلم والعنوان'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _summaryRow(String label, double value) {
    return Row(
      children: [
        Text(label, style: const TextStyle(color: QitafColors.muted)),
        const Spacer(),
        Text('${formatMoney(value)} ريال',
            style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    );
  }
}
