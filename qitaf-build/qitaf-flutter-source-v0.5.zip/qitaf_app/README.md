# Qitaf 0.5.0+5 — سلة البيت

A Flutter LOCAL commerce demo. Not a production marketplace.

## New in 0.5
- Removes illustrative public like/viewer counts and demo verification badges so social proof cannot be mistaken for real activity.
- Rewords the honey demo description to avoid an unsupported verification claim.
- Adds a live price breakdown in the product configurator: selected package price plus comparable price per base unit.
- Keeps all prices global and selection-based; there is no personalized pricing.
- Android application id remains com.qitaf.qitaf.demo3.

## New in 0.4
- Friendlier quick budget choices (3,000 / 5,000 / 10,000 / 20,000 YER) inside Home Basket, while keeping the existing manual “other amount” option.
- Clearer inclusive paths: «للبيت والعائلة» and «مختارات وهدايا».
- The helper copy makes it explicit that the visible total includes the current cart and estimated delivery.
- No personalized pricing: the budget chips only change the amount selected by the buyer; they never change product prices or fees.
- Android application id remains com.qitaf.qitaf.demo3.

## New in 0.3
- Home Basket: deterministic quantity suggestions within a chosen budget, including the existing cart and one estimated delivery fee.
- Home (tomato/mango) and family gift (coffee/honey) purposes, based on four existing demo products only.
- Editable quantities with local stock and total-budget guards. Physical stock quantity is independent of discounted price multipliers.
- Existing cart is preserved; gift opens the existing recipient/address screen with another recipient selected.
- Real on-device cart and product bookmarks persistence through SharedPreferences. Malformed data is handled without blocking startup.
- Optional Arabic read-aloud of summaries using the device TTS engine. An Arabic voice must be available. This is not speech recognition.
- Responsive feed header/navigation and clearer demo labels.

## Running
Use Flutter 3.47.2 as the CI baseline; Android Java 17. Generated Android and web scaffolds and pubspec.lock are included in the build artifact.

    flutter pub get
    flutter analyze
    flutter test --reporter expanded
    flutter run
    flutter build apk --release
    flutter build web --release --no-web-resources-cdn

## Installation
The demo uses applicationId com.qitaf.qitaf.demo3, separate from the old com.qitaf.qitaf package. It installs alongside v0.2 and does not migrate v0.2 local data. It is signed for testing, not a Play Store production release.

## Scope and privacy
All farms, prices, stock, viewer counts, orders, wallets, friend-payment requests and delivery fees are illustrative. No money moves, no public livestream starts and no request is sent to a friend or seller. Do not enter real financial credentials or sensitive address data.
The existing farmer studio contains camera preview/recording code, but physical-device camera and microphone testing is still required. The feed uses local illustrative assets, not real farm livestreams. Voice product/address entry from earlier demos remains simulated.
Local persistence stores only product IDs/selections/quantities/bookmarks and the UI role; it is not backend authentication and not financial storage. There is no scheduled purchase, nutritional guarantee, or automatic budget spending.
The browser ZIP requires HTTP(S) hosting; index.html alone via file:// is not a complete deployed website. Camera permissions require the browser's supported secure context.

## Testing
See the accompanying build report for the actual CI results and artifact checksum. Unit/widget tests are not evidence of a physical handset test.
