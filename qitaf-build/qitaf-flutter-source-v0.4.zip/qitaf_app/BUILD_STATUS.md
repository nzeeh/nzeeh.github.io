# Build scope

Version 0.4.0+4. The source is processed by GitHub Actions before artifacts are published. Inspect the corresponding workflow run for actual success/failure; this file is not a success certificate.

No live backend, real authentication, production wallet, inter-user livestream or delivery service is connected. Release mode is used for performance; the signing identity is a TEST identity. Android hardware and Arabic TTS must still be checked on the recipient device.
