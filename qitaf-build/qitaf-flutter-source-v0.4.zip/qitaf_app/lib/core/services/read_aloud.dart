import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Optional device voice, not speech recognition or a guarantee of an offline voice.
class ReadAloudButton extends StatefulWidget {
  const ReadAloudButton(
      {super.key, required this.text, this.label = 'اسمع الملخص'});
  final String text;
  final String label;
  @override
  State<ReadAloudButton> createState() => _ReadAloudButtonState();
}

class _ReadAloudButtonState extends State<ReadAloudButton> {
  FlutterTts? _tts;
  bool _busy = false;
  @override
  void dispose() {
    _stopSafely();
    super.dispose();
  }

  Future<void> _stopSafely() async {
    try {
      await _tts?.stop();
    } catch (_) {}
  }

  Future<void> _speak() async {
    if (_busy) {
      await _stopSafely();
      if (mounted) setState(() => _busy = false);
      return;
    }
    setState(() => _busy = true);
    try {
      final engine = _tts ??= FlutterTts();
      String? language;
      for (final code in ['ar-YE', 'ar-SA', 'ar']) {
        if (await engine.isLanguageAvailable(code) == true) {
          language = code;
          break;
        }
      }
      if (language == null) throw StateError('Arabic voice unavailable');
      await engine.setLanguage(language);
      await engine.setSpeechRate(0.42);
      await engine.awaitSpeakCompletion(true);
      await engine.speak(widget.text);
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text(
                'الصوت العربي غير متاح الآن على هذا الجهاز. الملخص مكتوب أمامك.')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
        onPressed: _speak,
        icon:
            Icon(_busy ? Icons.stop_circle_outlined : Icons.volume_up_rounded),
        label: Text(_busy ? 'إيقاف القراءة' : widget.label),
      );
}
