import 'dart:math' as math;
import 'product.dart';

enum BasketPurpose { home, gift }

/// Deterministic basket suggestions using the existing catalog, not a remote AI.
/// Budget includes the current cart and one estimated delivery fee.
List<CartItem> suggestBasket({
  required List<Product> products,
  required List<CartItem> currentCart,
  required int budgetRiyals,
  required int people,
  required BasketPurpose purpose,
  int deliveryRiyals = 1200,
}) {
  if (budgetRiyals < 0 || people < 1 || deliveryRiyals < 0) return [];
  final existingMinor =
      currentCart.fold<int>(0, (n, r) => n + (r.total * 100).round());
  var availableMinor =
      budgetRiyals * 100 - existingMinor - deliveryRiyals * 100;
  if (availableMinor <= 0) return [];
  final ids = purpose == BasketPurpose.home
      ? ['tomato-001', 'mango-001']
      : ['coffee-001', 'honey-001'];
  final eligible = ids
      .expand((id) => products.where((p) => p.id == id && p.stock > 0))
      .toList();
  final result = <CartItem>[];
  final used = <String, double>{};
  for (final r in currentCart) {
    used[r.product.id] = (used[r.product.id] ?? 0) +
        r.selection.weight.quantityInBaseUnits * r.selection.quantity;
  }
  ChoiceOption cheapest(List<ChoiceOption> options) =>
      options.reduce((a, b) => a.priceMultiplier <= b.priceMultiplier ? a : b);
  // A modest upper bound avoids filling a budget with excessive quantities.
  final target = purpose == BasketPurpose.home ? math.min(people, 6) : 1;
  for (var round = 0; round < target; round++) {
    for (final p in eligible) {
      if ([
        p.weightOptions,
        p.qualityOptions,
        p.ripenessOptions,
        p.packagingOptions
      ].any((l) => l.isEmpty)) continue;
      final weight = p.weightOptions.reduce(
          (a, b) => a.quantityInBaseUnits <= b.quantityInBaseUnits ? a : b);
      final selection = ProductSelection(
          weight: weight,
          quality: cheapest(p.qualityOptions),
          ripeness: cheapest(p.ripenessOptions),
          packaging: cheapest(p.packagingOptions),
          quantity: 1);
      final priceMinor = (selection.unitTotal(p) * 100).round();
      if (priceMinor <= 0 ||
          priceMinor > availableMinor ||
          (used[p.id] ?? 0) + weight.quantityInBaseUnits > p.stock + 0.000001)
        continue;
      final index = result.indexWhere((r) => r.product.id == p.id);
      if (index < 0) {
        result.add(CartItem(product: p, selection: selection));
      } else {
        result[index].selection =
            selection.copyWith(quantity: result[index].selection.quantity + 1);
      }
      availableMinor -= priceMinor;
      used[p.id] = (used[p.id] ?? 0) + weight.quantityInBaseUnits;
    }
  }
  return result;
}

int? parseBudget(String input) {
  const eastern = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  var s = input.trim();
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(eastern[i], '$i').replaceAll(persian[i], '$i');
  }
  s = s.replaceAll(RegExp(r'[\s,٬]'), '');
  if (!RegExp(r'^\d+$').hasMatch(s)) return null;
  final n = int.tryParse(s);
  return n != null && n >= 1 && n <= 1000000 ? n : null;
}
