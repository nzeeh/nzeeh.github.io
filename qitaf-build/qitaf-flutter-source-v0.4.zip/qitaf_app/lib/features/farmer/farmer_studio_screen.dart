import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import '../../core/models/product.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';

class FarmerStudioScreen extends StatelessWidget {
  const FarmerStudioScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const QitafWordmark(compact: true)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFE7F1EB),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0xFFBFD5C7)),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  backgroundColor: QitafColors.terraceGreen,
                  child: Icon(Icons.verified_rounded, color: Colors.white),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('حساب مزارع موثّق',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 16)),
                      Text('يمكنك التصوير والبيع مباشرة من مزرعتك.',
                          style: TextStyle(color: QitafColors.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const SectionTitle(
            title: 'صوّر وبِع',
            subtitle:
                'لا تحتاج إلى الكتابة. وجّه الكاميرا للمحصول، تحدث عنه، ثم ابدأ.',
          ),
          const SizedBox(height: 18),
          _modeCard(
            context,
            icon: Icons.sensors_rounded,
            title: 'ابدأ بثًا مباشرًا',
            description:
                'تحدث مع المشترين، أجب عن أسئلتهم وثبّت المنتج والسعر على الشاشة.',
            accent: QitafColors.live,
            tag: 'LIVE',
            mode: StudioMode.live,
          ),
          const SizedBox(height: 14),
          _modeCard(
            context,
            icon: Icons.video_camera_back_rounded,
            title: 'صوّر مقطعًا قصيرًا',
            description:
                'صوّر المحصول خلال أقل من دقيقة، واربطه بالمنتج ليظل يبيع بعد مغادرتك.',
            accent: QitafColors.burgundy,
            tag: 'قصير',
            mode: StudioMode.shortVideo,
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(24)),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ثلاث خطوات فقط',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 15),
                _SimpleStep(
                    number: '١',
                    icon: Icons.camera_alt_outlined,
                    title: 'وجّه الكاميرا',
                    subtitle: 'إلى المحصول أو المزرعة.'),
                _SimpleStep(
                    number: '٢',
                    icon: Icons.mic_none_rounded,
                    title: 'قل السعر والكمية',
                    subtitle: 'قِطاف يملأ بطاقة المنتج.'),
                _SimpleStep(
                    number: '٣',
                    icon: Icons.play_circle_outline_rounded,
                    title: 'اضغط ابدأ',
                    subtitle: 'وتظهر بطاقة الشراء للمشاهدين.'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _modeCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String description,
    required Color accent,
    required String tag,
    required StudioMode mode,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(26),
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
              builder: (_) => CameraStudioScreen(mode: mode)),
        ),
        borderRadius: BorderRadius.circular(26),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.13),
                    borderRadius: BorderRadius.circular(22)),
                child: Icon(icon, color: accent, size: 36),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Text(title,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 19))),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 9, vertical: 5),
                          decoration: BoxDecoration(
                              color: accent,
                              borderRadius: BorderRadius.circular(99)),
                          child: Text(tag,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(description,
                        style: const TextStyle(
                            color: QitafColors.muted, height: 1.55)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.arrow_back_ios_new_rounded,
                  size: 18, color: QitafColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _SimpleStep extends StatelessWidget {
  const _SimpleStep(
      {required this.number,
      required this.icon,
      required this.title,
      required this.subtitle});

  final String number;
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          CircleAvatar(
            radius: 19,
            backgroundColor: QitafColors.sand,
            child: Text(number,
                style: const TextStyle(
                    color: QitafColors.burgundy, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 11),
          Icon(icon, color: QitafColors.terraceGreen),
          const SizedBox(width: 9),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                    color: QitafColors.charcoal, fontFamily: 'sans-serif'),
                children: [
                  TextSpan(
                      text: '$title — ',
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                  TextSpan(
                      text: subtitle,
                      style: const TextStyle(color: QitafColors.muted)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

enum StudioMode { live, shortVideo }

class CameraStudioScreen extends StatefulWidget {
  const CameraStudioScreen({super.key, required this.mode});

  final StudioMode mode;

  @override
  State<CameraStudioScreen> createState() => _CameraStudioScreenState();
}

class _CameraStudioScreenState extends State<CameraStudioScreen>
    with WidgetsBindingObserver {
  List<CameraDescription> cameras = const [];
  CameraController? controller;
  Future<void>? initializeFuture;
  int cameraIndex = 0;
  bool micOn = true;
  bool flashOn = false;
  bool broadcasting = false;
  bool recording = false;
  int elapsedSeconds = 0;
  Timer? timer;
  String productName = 'طماطم بلدية';
  String price = '900';
  String stock = '86 كجم';
  Product pinnedProduct = demoProducts.first;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadCameras();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      controller?.dispose();
      controller = null;
    } else if (state == AppLifecycleState.resumed &&
        cameras.isNotEmpty &&
        controller == null) {
      _initializeCamera(cameraIndex);
    }
  }

  Future<void> _loadCameras() async {
    try {
      cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => errorMessage = 'لم يعثر الهاتف على كاميرا متاحة.');
        return;
      }
      await _initializeCamera(0);
    } on CameraException catch (error) {
      if (!mounted) return;
      setState(() => errorMessage = _cameraErrorText(error));
    } catch (_) {
      if (!mounted) return;
      setState(() => errorMessage =
          'تعذر تشغيل الكاميرا. اسمح للتطبيق باستخدامها ثم حاول مجددًا.');
    }
  }

  Future<void> _initializeCamera(int index) async {
    final oldController = controller;
    final nextController = CameraController(
      cameras[index],
      ResolutionPreset.medium,
      enableAudio: true,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    controller = nextController;
    cameraIndex = index;
    initializeFuture = nextController.initialize();
    await oldController?.dispose();
    try {
      await initializeFuture;
      if (!mounted) return;
      setState(() => errorMessage = null);
    } on CameraException catch (error) {
      if (!mounted) return;
      setState(() => errorMessage = _cameraErrorText(error));
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    timer?.cancel();
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final modeTitle = widget.mode == StudioMode.live
        ? 'بث مباشر من المزرعة'
        : 'مقطع قصير للمنتج';
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _cameraLayer(),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x99000000),
                  Color(0x00000000),
                  Color(0x00000000),
                  Color(0xCC000000)
                ],
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton.filled(
                        onPressed: () => Navigator.pop(context),
                        style: IconButton.styleFrom(
                            backgroundColor: Colors.black45,
                            foregroundColor: Colors.white),
                        icon: const Icon(Icons.close_rounded),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 13, vertical: 10),
                          decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius: BorderRadius.circular(999)),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (broadcasting) ...[
                                const LiveChip(label: 'على الهواء'),
                                const SizedBox(width: 8),
                              ],
                              Flexible(
                                  child: Text(modeTitle,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w900))),
                              if (broadcasting) ...[
                                const Spacer(),
                                Text(_formatDuration(elapsedSeconds),
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w800)),
                              ],
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton.filled(
                        onPressed: _switchCamera,
                        style: IconButton.styleFrom(
                            backgroundColor: Colors.black45,
                            foregroundColor: Colors.white),
                        icon: const Icon(Icons.cameraswitch_rounded),
                      ),
                    ],
                  ),
                  const Spacer(),
                  if (broadcasting)
                    Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(18)),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('أم محمد: هل يوجد توصيل إلى شملان؟',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 12)),
                            SizedBox(height: 5),
                            Text('علي: أرنا الصندوق أمام الكاميرا',
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  _pinnedProductCard(),
                  const SizedBox(height: 13),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _controlButton(
                        icon: micOn ? Icons.mic_rounded : Icons.mic_off_rounded,
                        label: micOn ? 'الميكروفون' : 'صامت',
                        active: micOn,
                        onTap: () => setState(() => micOn = !micOn),
                      ),
                      GestureDetector(
                        onTap: _toggleBroadcast,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          width: 86,
                          height: 86,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color:
                                broadcasting ? Colors.white : QitafColors.live,
                            border: Border.all(color: Colors.white, width: 5),
                            boxShadow: const [
                              BoxShadow(color: Colors.black45, blurRadius: 20)
                            ],
                          ),
                          child: Icon(
                            broadcasting
                                ? Icons.stop_rounded
                                : (widget.mode == StudioMode.live
                                    ? Icons.sensors_rounded
                                    : Icons.videocam_rounded),
                            color:
                                broadcasting ? QitafColors.live : Colors.white,
                            size: 43,
                          ),
                        ),
                      ),
                      _controlButton(
                        icon: Icons.graphic_eq_rounded,
                        label: 'قل البيانات',
                        active: true,
                        onTap: _voiceProductWizard,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    broadcasting
                        ? 'اضغط الدائرة لإيقاف ${widget.mode == StudioMode.live ? 'البث' : 'التسجيل'}'
                        : 'اضغط الدائرة الكبيرة للبدء',
                    style: const TextStyle(
                        color: Colors.white70, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _cameraLayer() {
    if (errorMessage != null) {
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF4F675F), Color(0xFF192721)]),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(30),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.no_photography_outlined,
                    color: Colors.white, size: 58),
                const SizedBox(height: 16),
                Text(errorMessage!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.white, height: 1.6, fontSize: 16)),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: _loadCameras,
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white)),
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('المحاولة مرة أخرى'),
                ),
              ],
            ),
          ),
        ),
      );
    }
    final cameraController = controller;
    if (cameraController == null || !cameraController.value.isInitialized) {
      return const Center(
          child: CircularProgressIndicator(color: Colors.white));
    }
    return Center(
      child: SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: cameraController.value.previewSize?.height ?? 1,
            height: cameraController.value.previewSize?.width ?? 1,
            child: CameraPreview(cameraController),
          ),
        ),
      ),
    );
  }

  Widget _pinnedProductCard() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.94),
          borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.asset(pinnedProduct.productAsset,
                  width: 62, height: 62, fit: BoxFit.cover)),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.push_pin_rounded,
                        size: 17, color: QitafColors.burgundy),
                    const SizedBox(width: 4),
                    const Text('المنتج المثبّت للمشاهدين',
                        style:
                            TextStyle(color: QitafColors.muted, fontSize: 11)),
                  ],
                ),
                Text(productName,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16)),
                Text('$price ريال / كجم · متوفر $stock',
                    style: const TextStyle(
                        color: QitafColors.burgundy,
                        fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          TextButton(onPressed: _selectProduct, child: const Text('تغيير')),
        ],
      ),
    );
  }

  Widget _controlButton(
      {required IconData icon,
      required String label,
      required bool active,
      required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: 80,
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
            color: Colors.black45,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white24)),
        child: Column(
          children: [
            Icon(icon, color: active ? Colors.white : Colors.white54),
            const SizedBox(height: 4),
            Text(label,
                style: TextStyle(
                    color: active ? Colors.white : Colors.white54,
                    fontSize: 11,
                    fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }

  Future<void> _switchCamera() async {
    if (cameras.length < 2) return;
    final next = (cameraIndex + 1) % cameras.length;
    await _initializeCamera(next);
  }

  Future<void> _toggleBroadcast() async {
    final cameraController = controller;
    if (cameraController == null || !cameraController.value.isInitialized) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('انتظر حتى تعمل الكاميرا.')));
      return;
    }

    if (broadcasting) {
      timer?.cancel();
      if (recording && cameraController.value.isRecordingVideo) {
        try {
          await cameraController.stopVideoRecording();
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        broadcasting = false;
        recording = false;
      });
      _showFinishedDialog();
      return;
    }

    if (widget.mode == StudioMode.shortVideo) {
      try {
        await cameraController.startVideoRecording();
        recording = true;
      } on CameraException catch (error) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_cameraErrorText(error))));
        return;
      }
    }

    setState(() {
      broadcasting = true;
      elapsedSeconds = 0;
    });
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => elapsedSeconds++);
    });
  }

  void _showFinishedDialog() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.check_circle_rounded,
            color: QitafColors.terraceGreen, size: 48),
        title: Text(widget.mode == StudioMode.live
            ? 'انتهى البث التجريبي'
            : 'تم حفظ المقطع التجريبي'),
        content: Text(
          widget.mode == StudioMode.live
              ? 'في النسخة المتصلة بالخادم سيُحفظ التسجيل ويظهر عدد المشاهدين والطلبات والمبيعات.'
              : 'تم اختبار الكاميرا والتسجيل. ربط رفع الفيديو بالخادم سيكون في مرحلة الربط الإنتاجي.',
          textAlign: TextAlign.center,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('حسنًا'))
        ],
      ),
    );
  }

  Future<void> _voiceProductWizard() async {
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (context) => VoiceProductDialog(
        initialName: productName,
        initialPrice: price,
        initialStock: stock,
      ),
    );
    if (result == null || !mounted) return;
    setState(() {
      productName = result['name'] ?? productName;
      price = result['price'] ?? price;
      stock = result['stock'] ?? stock;
    });
  }

  Future<void> _selectProduct() async {
    final selected = await showModalBottomSheet<Product>(
      context: context,
      showDragHandle: true,
      builder: (context) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        children: [
          const Text('اختر منتجًا لتثبيته في البث',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          ...demoProducts.map((product) => ListTile(
                onTap: () => Navigator.pop(context, product),
                leading: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(product.productAsset,
                        width: 54, height: 54, fit: BoxFit.cover)),
                title: Text(product.name,
                    style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(
                    '${formatMoney(product.basePrice)} ريال / ${product.unitLabel}'),
                trailing: const Icon(Icons.push_pin_outlined),
              )),
        ],
      ),
    );
    if (selected == null || !mounted) return;
    setState(() {
      pinnedProduct = selected;
      productName = selected.name;
      price = selected.basePrice.toStringAsFixed(0);
      stock = '${selected.stock} ${selected.unitLabel}';
    });
  }

  String _formatDuration(int value) {
    final minutes = (value ~/ 60).toString().padLeft(2, '0');
    final seconds = (value % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  String _cameraErrorText(CameraException error) {
    if (error.code == 'CameraAccessDenied' ||
        error.code == 'CameraAccessDeniedWithoutPrompt') {
      return 'تم رفض إذن الكاميرا. افتح إعدادات الهاتف واسمح لقِطاف باستخدام الكاميرا والميكروفون.';
    }
    if (error.code == 'AudioAccessDenied') {
      return 'تم رفض إذن الميكروفون. اسمح به كي يسمع المشترون شرحك.';
    }
    return 'تعذر تشغيل الكاميرا: ${error.description ?? error.code}';
  }
}

class VoiceProductDialog extends StatefulWidget {
  const VoiceProductDialog({
    super.key,
    required this.initialName,
    required this.initialPrice,
    required this.initialStock,
  });

  final String initialName;
  final String initialPrice;
  final String initialStock;

  @override
  State<VoiceProductDialog> createState() => _VoiceProductDialogState();
}

class _VoiceProductDialogState extends State<VoiceProductDialog> {
  bool listening = false;
  late final TextEditingController nameController;
  late final TextEditingController priceController;
  late final TextEditingController stockController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.initialName);
    priceController = TextEditingController(text: widget.initialPrice);
    stockController = TextEditingController(text: widget.initialStock);
  }

  @override
  void dispose() {
    nameController.dispose();
    priceController.dispose();
    stockController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('قل بيانات محصولك', textAlign: TextAlign.center),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: _listen,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                width: 92,
                height: 92,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: listening ? QitafColors.live : QitafColors.burgundy,
                  boxShadow: [
                    BoxShadow(
                        color: QitafColors.burgundy.withValues(alpha: 0.25),
                        blurRadius: listening ? 26 : 10,
                        spreadRadius: listening ? 8 : 1)
                  ],
                ),
                child: Icon(
                    listening ? Icons.graphic_eq_rounded : Icons.mic_rounded,
                    color: Colors.white,
                    size: 46),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              listening ? 'أستمع إليك…' : 'اضغط وتحدث بدل الكتابة',
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 5),
            const Text(
              'مثال: طماطم بلدية، تسعمائة ريال للكيلو، والمتوفر ستة وثمانون كيلو.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: QitafColors.muted, height: 1.5, fontSize: 12),
            ),
            const SizedBox(height: 16),
            TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'اسم المنتج')),
            const SizedBox(height: 10),
            TextField(
                controller: priceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'السعر بالريال')),
            const SizedBox(height: 10),
            TextField(
                controller: stockController,
                decoration:
                    const InputDecoration(labelText: 'الكمية المتوفرة')),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء')),
        FilledButton(
          onPressed: () => Navigator.pop(context, {
            'name': nameController.text.trim(),
            'price': priceController.text.trim(),
            'stock': stockController.text.trim(),
          }),
          child: const Text('نعم، صحيحة'),
        ),
      ],
    );
  }

  Future<void> _listen() async {
    setState(() => listening = true);
    await Future<void>.delayed(const Duration(milliseconds: 1300));
    if (!mounted) return;
    setState(() {
      listening = false;
      nameController.text = 'طماطم بلدية';
      priceController.text = '900';
      stockController.text = '86 كجم';
    });
  }
}
