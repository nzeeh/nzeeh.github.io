import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/models/product.dart';
import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';
import '../product/product_sheet.dart';
import '../basket/home_basket_screen.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final PageController _controller = PageController();
  int _active = 0;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      controller: _controller,
      scrollDirection: Axis.vertical,
      itemCount: demoProducts.length,
      onPageChanged: (value) => setState(() => _active = value),
      itemBuilder: (context, index) {
        return FarmVideoCard(
          product: demoProducts[index],
          isActive: index == _active,
          index: index,
        );
      },
    );
  }
}

class FarmVideoCard extends StatefulWidget {
  const FarmVideoCard({
    super.key,
    required this.product,
    required this.isActive,
    required this.index,
  });

  final Product product;
  final bool isActive;
  final int index;

  @override
  State<FarmVideoCard> createState() => _FarmVideoCardState();
}

class _FarmVideoCardState extends State<FarmVideoCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  bool _following = false;
  int _heartBurst = 0;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
      lowerBound: 0,
      upperBound: 1,
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final store = AppScope.of(context);
    final liked = store.isLiked(product.id);

    return Stack(
      fit: StackFit.expand,
      children: [
        AnimatedScale(
          scale: widget.isActive ? 1.035 : 1,
          duration: const Duration(seconds: 6),
          curve: Curves.easeOut,
          child: Image.asset(product.feedAsset, fit: BoxFit.cover),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0x55000000),
                Color(0x00000000),
                Color(0x22000000),
                Color(0xD9000000),
              ],
              stops: [0, 0.36, 0.55, 1],
            ),
          ),
        ),
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
            child: Align(
              alignment: Alignment.topCenter,
              child: Row(
                children: [
                  const QitafWordmark(onDark: true, compact: true),
                  const SizedBox(width: 8),
                  if (MediaQuery.sizeOf(context).width >= 500) ...[
                    _topTab('لك', true),
                    const SizedBox(width: 10),
                    _topTab('مباشر', false),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                      child: Align(
                          alignment: Alignment.center,
                          child: TextButton.icon(
                            onPressed: () => openHomeBasket(context),
                            style: TextButton.styleFrom(
                                foregroundColor: const Color(0xFFFFD269),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8)),
                            icon: const Icon(Icons.shopping_basket_outlined,
                                size: 19),
                            label: const Text('سلة البيت',
                                style: TextStyle(fontWeight: FontWeight.w900)),
                          ))),
                  IconButton.filledTonal(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text(
                                'البحث الصوتي سيُفعّل في النسخة المتصلة بالخادم.')),
                      );
                    },
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.black38,
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.search_rounded),
                  ),
                ],
              ),
            ),
          ),
        ),
        PositionedDirectional(
          top: 100,
          start: 18,
          child: Row(
            children: [
              const LiveChip(label: 'عرض تجريبي'),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.black45,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: Colors.white24),
                ),
                child: Text(
                  'أرقام توضيحية',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
        ),
        PositionedDirectional(
          end: 14,
          bottom: 205,
          child: Column(
            children: [
              _farmerAvatar(product),
              const SizedBox(height: 17),
              _action(
                icon: liked
                    ? Icons.favorite_rounded
                    : Icons.favorite_border_rounded,
                label: compactCount(product.likes + (liked ? 1 : 0)),
                color: liked ? const Color(0xFFFF4964) : Colors.white,
                onTap: () {
                  store.toggleLike(product.id);
                  setState(() => _heartBurst++);
                  _pulseController.forward(from: 0);
                },
              ),
              _action(
                icon: Icons.mode_comment_outlined,
                label: 'اسأل',
                onTap: () => _openComments(context, product),
              ),
              _action(
                icon: Icons.ios_share_rounded,
                label: 'شارك',
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text(
                          'المشاركة العامة غير متصلة بعد. احفظ المنتج للرجوع إليه.')),
                ),
              ),
              _action(
                icon: store.isSaved(product.id)
                    ? Icons.bookmark_rounded
                    : Icons.bookmark_border_rounded,
                label: store.isSaved(product.id) ? 'محفوظ' : 'حفظ',
                color: store.isSaved(product.id)
                    ? const Color(0xFFFFD269)
                    : Colors.white,
                onTap: () => store.toggleSaved(product.id),
              ),
            ],
          ),
        ),
        PositionedDirectional(
          start: 18,
          end: 82,
          bottom: 184,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      product.farmerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w900),
                    ),
                  ),
                  if (product.isVerified) ...[
                    const SizedBox(width: 6),
                    const Icon(Icons.verified_rounded,
                        color: Color(0xFFFFD269), size: 19),
                  ],
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 34,
                    child: OutlinedButton(
                      onPressed: () => setState(() => _following = !_following),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: BorderSide(
                            color: _following ? Colors.white38 : Colors.white),
                        backgroundColor: _following
                            ? Colors.white12
                            : QitafColors.burgundy.withValues(alpha: 0.82),
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        minimumSize: Size.zero,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(999)),
                      ),
                      child: Text(_following ? 'تتابعه' : 'متابعة',
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(product.shortDescription,
                  style: const TextStyle(
                      color: Colors.white,
                      height: 1.45,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(Icons.location_on_outlined,
                      color: Colors.white70, size: 17),
                  const SizedBox(width: 4),
                  Expanded(
                      child: Text(product.location,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 13))),
                ],
              ),
            ],
          ),
        ),
        PositionedDirectional(
          start: 12,
          end: 12,
          bottom: 86,
          child: _productCard(context, product),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedBuilder(
              key: ValueKey(_heartBurst),
              animation: _pulseController,
              builder: (context, child) {
                final t = _pulseController.value;
                if (t == 0 || t == 1) return const SizedBox.shrink();
                return Stack(
                  children: List.generate(5, (index) {
                    final drift = math.sin((t + index) * 5) * 25;
                    return PositionedDirectional(
                      end: 30 + drift + index * 3,
                      bottom: 310 + t * 230 + index * 16,
                      child: Opacity(
                        opacity: 1 - t,
                        child: Transform.scale(
                          scale: 0.8 + t * 0.8,
                          child: const Icon(Icons.favorite,
                              color: Color(0xFFFF4964), size: 34),
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _topTab(String label, bool selected) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label,
            style: TextStyle(
                color: selected ? Colors.white : Colors.white70,
                fontWeight: selected ? FontWeight.w900 : FontWeight.w700)),
        const SizedBox(height: 4),
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: selected ? 20 : 0,
          height: 3,
          decoration: BoxDecoration(
              color: const Color(0xFFFFD269),
              borderRadius: BorderRadius.circular(99)),
        ),
      ],
    );
  }

  Widget _farmerAvatar(Product product) {
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.bottomCenter,
      children: [
        Container(
          width: 53,
          height: 53,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2)),
          child: ClipOval(
              child: Image.asset(product.productAsset, fit: BoxFit.cover)),
        ),
        const Positioned(
          bottom: -9,
          child: CircleAvatar(
            radius: 11,
            backgroundColor: QitafColors.burgundy,
            child: Icon(Icons.add, color: Colors.white, size: 17),
          ),
        ),
      ],
    );
  }

  Widget _action({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color color = Colors.white,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        children: [
          IconButton.filled(
            onPressed: onTap,
            style: IconButton.styleFrom(
                backgroundColor: Colors.black38, foregroundColor: color),
            icon: Icon(icon, size: 29),
          ),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _productCard(BuildContext context, Product product) {
    return Material(
      color: Colors.white.withValues(alpha: 0.96),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: () => showProductConfigurator(context, product),
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(product.productAsset,
                    width: 65, height: 65, fit: BoxFit.cover),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(
                      '${formatMoney(product.basePrice)} ريال / ${product.unitLabel}',
                      style: const TextStyle(
                          color: QitafColors.burgundy,
                          fontWeight: FontWeight.w900,
                          fontSize: 17),
                    ),
                    Text('متوفر الآن · ${product.stock} ${product.unitLabel}',
                        style: const TextStyle(
                            color: QitafColors.terraceGreen,
                            fontSize: 12,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () => showProductConfigurator(context, product),
                style: FilledButton.styleFrom(
                  minimumSize: const Size(102, 48),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)),
                ),
                child:
                    const Text('اختر واشترِ', style: TextStyle(fontSize: 13)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openComments(BuildContext context, Product product) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      builder: (context) {
        const comments = [
          ('أم محمد', 'هل يوجد توصيل إلى شملان؟'),
          ('علي', 'أرنا الصندوق أمام الكاميرا لو سمحت.'),
          ('سلمى', 'متى تم الحصاد؟'),
        ];
        return Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('أسئلة مباشرة إلى ${product.farmerName}',
                  style: const TextStyle(
                      fontSize: 19, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              ...comments.map((entry) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                        backgroundColor: QitafColors.sand,
                        child: Text(entry.$1.substring(0, 1))),
                    title: Text(entry.$1,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(entry.$2),
                  )),
              const SizedBox(height: 8),
              TextField(
                decoration: InputDecoration(
                  hintText: 'اكتب أو اضغط الميكروفون للسؤال',
                  prefixIcon: const Icon(Icons.mic_rounded,
                      color: QitafColors.burgundy),
                  suffixIcon: IconButton(
                      onPressed: () {}, icon: const Icon(Icons.send_rounded)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
