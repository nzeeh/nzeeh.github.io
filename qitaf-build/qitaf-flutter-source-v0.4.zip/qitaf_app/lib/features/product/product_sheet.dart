import 'package:flutter/material.dart';
import '../../core/models/product.dart';
import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';

Future<bool?> showProductConfigurator(
  BuildContext context,
  Product product, {
  bool buyNow = false,
}) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (context) =>
        ProductConfiguratorSheet(product: product, buyNow: buyNow),
  );
}

class ProductConfiguratorSheet extends StatefulWidget {
  const ProductConfiguratorSheet({
    super.key,
    required this.product,
    this.buyNow = false,
  });

  final Product product;
  final bool buyNow;

  @override
  State<ProductConfiguratorSheet> createState() =>
      _ProductConfiguratorSheetState();
}

class _ProductConfiguratorSheetState extends State<ProductConfiguratorSheet> {
  late ProductSelection selection;

  @override
  void initState() {
    super.initState();
    selection = ProductSelection(
      weight: widget.product.weightOptions.first,
      quality: widget.product.qualityOptions.first,
      ripeness: widget.product.ripenessOptions.first,
      packaging: widget.product.packagingOptions.first,
      quantity: 1,
    );
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final bottomPadding = MediaQuery.viewInsetsOf(context).bottom;
    return Container(
      constraints:
          BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.92),
      padding: EdgeInsets.only(bottom: bottomPadding),
      decoration: const BoxDecoration(
        color: QitafColors.ivory,
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
                color: Colors.black12, borderRadius: BorderRadius.circular(99)),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset(product.productAsset,
                          width: 106, height: 106, fit: BoxFit.cover),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(product.name,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 5),
                          Text(product.shortDescription,
                              style: const TextStyle(
                                  color: QitafColors.muted, height: 1.4)),
                          const SizedBox(height: 9),
                          Text(
                            '${formatMoney(product.basePrice)} ريال / ${product.unitLabel}',
                            style: const TextStyle(
                                color: QitafColors.burgundy,
                                fontSize: 18,
                                fontWeight: FontWeight.w900),
                          ),
                          Text(
                            'المتوفر ${product.stock} ${product.unitLabel}',
                            style: const TextStyle(
                                color: QitafColors.terraceGreen,
                                fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _choiceSection(
                    'الوزن أو العبوة', product.weightOptions, selection.weight,
                    (value) {
                  setState(() => selection = selection.copyWith(weight: value));
                }),
                _choiceSection(
                    'الفرز والجودة', product.qualityOptions, selection.quality,
                    (value) {
                  setState(
                      () => selection = selection.copyWith(quality: value));
                }),
                _choiceSection('اللون أو درجة التجهيز', product.ripenessOptions,
                    selection.ripeness, (value) {
                  setState(
                      () => selection = selection.copyWith(ripeness: value));
                }),
                _choiceSection(
                    'التغليف', product.packagingOptions, selection.packaging,
                    (value) {
                  setState(
                      () => selection = selection.copyWith(packaging: value));
                }),
                const Text('عدد الوحدات',
                    style:
                        TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: QuantityStepper(
                    value: selection.quantity,
                    onMinus: () => setState(() {
                      if (selection.quantity > 1) {
                        selection = selection.copyWith(
                            quantity: selection.quantity - 1);
                      }
                    }),
                    onPlus: () => setState(() {
                      if ((selection.quantity + 1) *
                              selection.weight.quantityInBaseUnits <=
                          product.stock) {
                        selection = selection.copyWith(
                            quantity: selection.quantity + 1);
                      }
                    }),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 16),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.black12,
                    blurRadius: 24,
                    offset: Offset(0, -7))
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('الإجمالي',
                            style: TextStyle(color: QitafColors.muted)),
                        Text(
                          '${formatMoney(selection.lineTotal(product))} ريال',
                          style: const TextStyle(
                              fontSize: 22,
                              color: QitafColors.burgundy,
                              fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: FilledButton.icon(
                      onPressed: _add,
                      icon: Icon(widget.buyNow
                          ? Icons.flash_on_rounded
                          : Icons.shopping_bag_rounded),
                      label:
                          Text(widget.buyNow ? 'اشترِ الآن' : 'أضف إلى السلة'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _choiceSection(
    String title,
    List<ChoiceOption> options,
    ChoiceOption selected,
    ValueChanged<ChoiceOption> onSelected,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 9,
            runSpacing: 9,
            children: options
                .map((option) => ChoicePill(
                      label: option.label,
                      selected: option.label == selected.label,
                      onTap: () => onSelected(option),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }

  void _add() {
    final messenger = ScaffoldMessenger.of(context);
    final store = AppScope.of(context);
    if (!store.addToCart(widget.product, selection)) {
      messenger.showSnackBar(
          SnackBar(content: Text(store.lastCartError ?? 'تعذر إضافة الكمية.')));
      return;
    }
    Navigator.pop(context, true);
    messenger.showSnackBar(
      SnackBar(
        content: Text('أُضيف ${widget.product.name} إلى السلة'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
