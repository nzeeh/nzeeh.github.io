import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Home Basket exposes inclusive quick budgets and manual amount', () {
    final source =
        File('lib/features/basket/home_basket_screen.dart').readAsStringSync();
    expect(
        RegExp(r'\[\s*3000\s*,\s*5000\s*,\s*10000\s*,\s*20000\s*\]')
            .hasMatch(source),
        isTrue);
    expect(source, contains('_refresh(() => _budget = value)'));
    expect(source, contains('مبلغ آخر'));
    expect(source, contains('للبيت والعائلة'));
    expect(source, contains('مختارات وهدايا'));
    expect(source, contains('التوصيل التقديري'));
  });
}
