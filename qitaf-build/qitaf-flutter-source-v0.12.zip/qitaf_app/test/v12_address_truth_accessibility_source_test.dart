import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('recipient fields are blank by default instead of realistic demo data',
      () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains('final nameController = TextEditingController();'));
    expect(
        source, contains('final phoneController = TextEditingController();'));
    expect(source, contains('final cityController = TextEditingController();'));
    expect(source, isNot(contains("TextEditingController(text: 'محمد')")));
    expect(
        source, isNot(contains("TextEditingController(text: '77 123 4567')")));
  });

  test('address audio is read-aloud guidance and never pretends to hear speech',
      () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains("ValueKey('address-audio-guide')"));
    expect(source, contains("label: 'اسمع الطريقة'"));
    expect(source, contains('هذه النسخة لا تستمع إلى الميكروفون'));
    expect(source, isNot(contains('_simulateVoiceAddress')));
    expect(source, isNot(contains('فهمت العنوان وملأت الحقول')));
  });

  test(
      'map action is explicitly a preview and does not claim saved coordinates',
      () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains('معاينة مكان الباب'));
    expect(
        source, contains('الخريطة غير متصلة ولا تُحفظ إحداثيات أو موقع حقيقي'));
    expect(source, isNot(contains('تم تثبيت نقطة تجريبية على الخريطة')));
    expect(source, isNot(contains('حدد الباب على الخريطة')));
  });
}
