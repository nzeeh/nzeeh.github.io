import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('demo social proof is not presented as real data', () {
    final model = File('lib/core/models/product.dart').readAsStringSync();
    final feed = File('lib/features/feed/feed_screen.dart').readAsStringSync();
    expect(model, contains('this.isVerified = false'));
    expect(RegExp(r'likes:\s*[1-9]').hasMatch(model), isFalse);
    expect(RegExp(r'viewers:\s*[1-9]').hasMatch(model), isFalse);
    expect(model, isNot(contains('خلية موثقة')));
    expect(feed, isNot(contains('compactCount(product.likes')));
    expect(feed, contains("liked ? 'تم' : 'إعجاب'"));
    expect(feed, contains('بيانات تجريبية'));
  });

  test('product configurator exposes comparable unit price', () {
    final source =
        File('lib/features/product/product_sheet.dart').readAsStringSync();
    expect(source, contains("ValueKey('unit-price-breakdown')"));
    expect(source, contains("ValueKey('comparable-unit-price')"));
    expect(source, contains('selectedPackagePrice / selectedBaseUnits'));
    expect(source, contains('قبل التوصيل'));
  });
}
