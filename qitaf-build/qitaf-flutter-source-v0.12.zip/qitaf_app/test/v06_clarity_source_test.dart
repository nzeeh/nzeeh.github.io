import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Home Basket explains editability and no automatic purchase', () {
    final source =
        File('lib/features/basket/home_basket_screen.dart').readAsStringSync();
    expect(source, contains('يمكنك تعديل الكميات قبل الإضافة'));
    expect(source, contains('لا يوجد شراء تلقائي'));
    expect(source, contains('التوصيل التقديري'));
  });

  test('Product configurator states the same-price rule', () {
    final source =
        File('lib/features/product/product_sheet.dart').readAsStringSync();
    expect(source, contains("ValueKey('same-price-rule')"));
    expect(source, contains('السعر نفسه للجميع'));
    expect(source, contains('الوزن أو التجهيز أو التغليف'));
    expect(source, contains("ValueKey('comparable-unit-price')"));
  });
}
