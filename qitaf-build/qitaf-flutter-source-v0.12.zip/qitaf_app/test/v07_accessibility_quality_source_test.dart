import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Home Basket welcomes lower or different manual budgets', () {
    final source =
        File('lib/features/basket/home_basket_screen.dart').readAsStringSync();
    expect(source, contains('ميزانيتك أقل أو مختلفة؟'));
    expect(source, contains('اكتب المبلغ الذي يناسبك'));
    expect(source, contains('مبلغ آخر'));
    expect(source, contains('لا يوجد شراء تلقائي'));
  });

  test('deprecated activeColor property stays removed from checkout', () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, isNot(contains('activeColor:')));
    expect(source, contains('activeThumbColor:'));
  });
}
