import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qitaf/main.dart';
import 'package:qitaf/features/basket/home_basket_screen.dart';
import 'package:qitaf/features/checkout/checkout_flow.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> launch(WidgetTester tester) async {
  SharedPreferences.setMockInitialValues({'qitaf_user_role': 'buyer'});
  await tester.pumpWidget(const QitafApp());
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('Open home basket directly from the feed', (t) async {
    await launch(t);
    await t.tap(find.text('سلة البيت').first);
    await t.pumpAndSettle();
    expect(find.byType(HomeBasketScreen), findsOneWidget);
    await t.scrollUntilVisible(find.text('حدّد ميزانيتك'), 180,
        scrollable: find
            .descendant(
                of: find.byType(HomeBasketScreen),
                matching: find.byType(Scrollable))
            .first);
    await t.pumpAndSettle();
    expect(find.text('حدّد ميزانيتك'), findsOneWidget);
    expect(t.takeException(), isNull);
  });
  testWidgets('Home basket adds to cart and opens recipient selection',
      (t) async {
    await launch(t);
    await t.tap(find.text('سلة البيت').first);
    await t.pumpAndSettle();
    await t.tap(find.byKey(const ValueKey('basket-checkout')));
    await t.pumpAndSettle();
    expect(find.byType(RecipientAddressScreen), findsOneWidget);
    expect(find.text('لمن سنوصل القطفة؟'), findsOneWidget);
  });
  testWidgets('Gift mode preselects another recipient', (t) async {
    await launch(t);
    await t.tap(find.text('سلة البيت').first);
    await t.pumpAndSettle();
    await t.ensureVisible(find.text('مختارات وهدايا'));
    await t.tap(find.text('مختارات وهدايا'));
    await t.pumpAndSettle();
    await t.tap(find.byKey(const ValueKey('basket-checkout')));
    await t.pumpAndSettle();
    expect(
        t
            .widget<RecipientAddressScreen>(find.byType(RecipientAddressScreen))
            .forSomeoneElse,
        isTrue);
  });
  testWidgets('New basket layout is usable on a narrow phone', (t) async {
    t.view.physicalSize = const Size(360, 800);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.resetPhysicalSize);
    addTearDown(t.view.resetDevicePixelRatio);
    await launch(t);
    expect(t.takeException(), isNull);
    await t.tap(find.text('سلة البيت').first);
    await t.pumpAndSettle();
    expect(t.takeException(), isNull);
    await t.drag(find.byType(ListView).last, const Offset(0, -650));
    await t.pumpAndSettle();
    expect(find.byKey(const ValueKey('basket-checkout')), findsOneWidget);
    expect(t.takeException(), isNull);
  });
}
