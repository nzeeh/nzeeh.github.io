import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('payment selection uses RadioGroup without deprecated Radio callbacks',
      () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains('RadioGroup<String>('));
    expect(source, contains('Radio<String>(value: value)'));
    expect(source,
        isNot(contains('groupValue: method,\n                onChanged:')));
  });

  test('friend payment is explicitly a non-sending simulation', () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains('لا يُرسل رابط فعلي في هذه النسخة'));
    expect(source, contains('لا يُرسل أي اتصال أو رسالة من هذه النسخة'));
    expect(source, contains('لم يُرسل أي رابط إلى'));
    expect(source, contains('لا يوجد حجز فعلي للمحصول أو تحويل أموال'));
    expect(source, contains('مؤقت تجريبي'));
    expect(source, isNot(contains('أرسلنا طلب الدفع')));
    expect(source, isNot(contains('تم إرسال رابط آمن إلى')));
  });
}
