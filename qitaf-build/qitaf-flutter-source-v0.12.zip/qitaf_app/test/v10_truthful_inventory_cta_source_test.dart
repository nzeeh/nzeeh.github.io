import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('feed labels demo inventory and exposes smallest pack', () {
    final source =
        File('lib/features/feed/feed_screen.dart').readAsStringSync();
    expect(source, contains('مخزون تجريبي'));
    expect(source, contains("ValueKey('smallest-pack-label')"));
    expect(source, contains('أصغر عبوة:'));
    expect(source, contains('اختر الكمية'));
    expect(source, isNot(contains('متوفر الآن ·')));
    expect(source, isNot(contains('اختر واشترِ')));
  });

  test(
      'product configurator describes local add action, not a completed purchase',
      () {
    final source =
        File('lib/features/product/product_sheet.dart').readAsStringSync();
    expect(source, contains('مخزون تجريبي'));
    expect(source, contains("widget.buyNow ? 'أضف وتابع' : 'أضف إلى السلة'"));
    expect(source, isNot(contains("widget.buyNow ? 'اشترِ الآن'")));
  });

  test('buyer onboarding says prepare order instead of completed purchase', () {
    final source = File('lib/features/onboarding/role_selection_screen.dart')
        .readAsStringSync();
    expect(source, contains('أشاهد المزارعين وأجهّز طلبي من أرضه.'));
    expect(source, contains('تجهيز سريع للسلة'));
    expect(source, isNot(contains('أشاهد المزارعين وأشتري المنتج من أرضه.')));
  });
}
