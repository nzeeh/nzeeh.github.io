import 'package:flutter_test/flutter_test.dart';
import 'package:qitaf/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('Qitaf asks whether the user is a buyer or seller', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});

    await tester.pumpWidget(const QitafApp());
    await tester.pumpAndSettle();

    expect(find.text('هل أنت بائع أم مشتري؟'), findsOneWidget);
    expect(find.text('أنا مشتري'), findsOneWidget);
    expect(find.text('أنا بائع / مزارع'), findsOneWidget);
  });

  testWidgets('buyer selection opens the vertical farm feed', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});

    await tester.pumpWidget(const QitafApp());
    await tester.pumpAndSettle();
    await tester.tap(find.text('أنا مشتري'));
    await tester.pumpAndSettle();

    expect(find.text('اختر الكمية'), findsOneWidget);
    expect(find.text('المقاطع'), findsOneWidget);
    expect(find.text('وضع البائع'), findsOneWidget);
  });

  testWidgets('saved seller role opens the simple farmer dashboard', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'qitaf_user_role': 'seller',
    });

    await tester.pumpWidget(const QitafApp());
    await tester.pumpAndSettle();

    expect(find.text('أهلًا بك يا مزارع 👋'), findsOneWidget);
    expect(find.text('افتح معاينة الكاميرا'), findsOneWidget);
    expect(find.text('لوحتي'), findsOneWidget);
    expect(find.text('صوّر واعرض'), findsOneWidget);
  });
}
