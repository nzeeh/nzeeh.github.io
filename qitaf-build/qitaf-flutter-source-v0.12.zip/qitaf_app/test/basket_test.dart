import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:qitaf/core/models/product.dart';
import 'package:qitaf/core/models/basket_plan.dart';
import 'package:qitaf/core/state/app_store.dart';

ProductSelection basic(Product p,
        {int quantity = 1, int weight = 0, int quality = 1}) =>
    ProductSelection(
        weight: p.weightOptions[weight],
        quality: p.qualityOptions[quality],
        ripeness: p.ripenessOptions.first,
        packaging: p.packagingOptions.first,
        quantity: quantity);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));
  test('Eastern and Western digits parse to the same budget', () {
    expect(parseBudget('١٠٬٠٠٠'), 10000);
    expect(parseBudget('10,000'), 10000);
    expect(parseBudget('۲۰۰۰۰'), 20000);
    expect(parseBudget('-1'), isNull);
    expect(parseBudget('not money'), isNull);
    expect(parseBudget('1000001'), isNull);
    expect(parseBudget('1.5'), isNull);
  });
  test('The budget includes existing cart and delivery for all presets', () {
    for (final budget in [1000, 4000, 7000, 10000, 20000]) {
      for (final mode in BasketPurpose.values) {
        for (final people in [2, 4, 6]) {
          final old = [
            CartItem(
                product: demoProducts[0], selection: basic(demoProducts[0]))
          ];
          final rows = suggestBasket(
              products: demoProducts,
              currentCart: old,
              budgetRiyals: budget,
              people: people,
              purpose: mode);
          if (rows.isEmpty) continue;
          final amount = rows.fold<double>(0, (n, r) => n + r.total) +
              old.first.total +
              1200;
          expect(amount, lessThanOrEqualTo(budget),
              reason: '$budget / $mode / $people');
        }
      }
    }
  });
  test('The gift contains coffee and honey when the budget permits', () {
    final rows = suggestBasket(
        products: demoProducts,
        currentCart: [],
        budgetRiyals: 10000,
        people: 4,
        purpose: BasketPurpose.gift);
    expect(rows.map((r) => r.product.id),
        containsAll(['coffee-001', 'honey-001']));
  });
  test('Insufficient budget and empty catalog produce no false offer', () {
    expect(
        suggestBasket(
            products: demoProducts,
            currentCart: [],
            budgetRiyals: 1000,
            people: 4,
            purpose: BasketPurpose.home),
        isEmpty);
    expect(
        suggestBasket(
            products: [],
            currentCart: [],
            budgetRiyals: 10000,
            people: 4,
            purpose: BasketPurpose.home),
        isEmpty);
  });
  test('A discounted 10 kg box consumes 10 kg not 9.2 kg', () async {
    final store = AppStore();
    await store.initialize();
    final p = demoProducts.first;
    expect(p.weightOptions[3].quantityInBaseUnits, 10);
    expect(store.addToCart(p, basic(p, weight: 3, quantity: 8)), isTrue);
    expect(store.reservedUnits(p.id), 80);
    expect(store.addToCart(p, basic(p, weight: 3)), isFalse);
    expect(store.reservedUnits(p.id), 80);
    await store.saved;
    store.dispose();
  });
  test('Stock is aggregated across quality variants', () async {
    final store = AppStore();
    await store.initialize();
    final p = demoProducts.first;
    expect(store.addToCart(p, basic(p, quantity: 80)), isTrue);
    expect(store.addToCart(p, basic(p, quantity: 7, quality: 0)), isFalse);
    expect(store.cartCount, 80);
    await store.saved;
    store.dispose();
  });
  test('A bundle exceeding stock is rejected atomically', () async {
    final store = AppStore();
    await store.initialize();
    final rows = [
      CartItem(product: demoProducts[1], selection: basic(demoProducts[1])),
      CartItem(
          product: demoProducts[0],
          selection: basic(demoProducts[0], quantity: 1000))
    ];
    expect(store.addBundle(rows), isFalse);
    expect(store.cart, isEmpty);
    store.dispose();
  });
  test('Budget validation accounts for the whole cart', () async {
    final store = AppStore();
    await store.initialize();
    final p = demoProducts.first;
    store.addToCart(p, basic(p, quantity: 3));
    expect(
        store.addBundle([CartItem(product: p, selection: basic(p))],
            budgetRiyals: 4000),
        isFalse);
    expect(store.cartCount, 3);
    await store.saved;
    store.dispose();
  });
  test('Cart and bookmarks survive a restart', () async {
    final first = AppStore();
    await first.initialize();
    first.addToCart(demoProducts[0], basic(demoProducts[0], quantity: 2));
    first.toggleSaved(demoProducts[2].id);
    await first.saved;
    final second = AppStore();
    await second.initialize();
    expect(second.cartCount, 2);
    expect(second.isSaved(demoProducts[2].id), isTrue);
    expect(second.subtotal, first.subtotal);
    first.dispose();
    second.dispose();
  });
  test('Corrupt saved cart does not crash launch or remove a saved role',
      () async {
    SharedPreferences.setMockInitialValues(
        {'qitaf_user_role': 'buyer', 'qitaf_cart_v3': '{not json'});
    final store = AppStore();
    await store.initialize();
    expect(store.isReady, isTrue);
    expect(store.isBuyer, isTrue);
    expect(store.cart, isEmpty);
    store.dispose();
  });
  test('Rapid edits persist only the latest cart state', () async {
    final first = AppStore();
    await first.initialize();
    first.addToCart(demoProducts[0], basic(demoProducts[0]));
    first.increment(first.cart.first);
    first.clearCart();
    await first.saved;
    final second = AppStore();
    await second.initialize();
    expect(second.cart, isEmpty);
    first.dispose();
    second.dispose();
  });
  test('A ready suggested basket is added without changing its total',
      () async {
    final store = AppStore();
    await store.initialize();
    final rows = suggestBasket(
        products: demoProducts,
        currentCart: store.cart,
        budgetRiyals: 10000,
        people: 4,
        purpose: BasketPurpose.home);
    final proposed = rows.fold<double>(0, (n, r) => n + r.total) + 1200;
    expect(store.addBundle(rows, budgetRiyals: 10000), isTrue);
    expect(store.total, proposed);
    expect(store.total, lessThanOrEqualTo(10000));
    await store.saved;
    store.dispose();
  });
}
