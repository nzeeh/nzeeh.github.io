import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
      'seller dashboard has no fabricated activity metrics or verification cue',
      () {
    final source =
        File('lib/features/farmer/seller_home_screen.dart').readAsStringSync();
    expect(source, contains('طلبات غير متصلة'));
    expect(source, contains('مشاهدات غير متصلة'));
    expect(source, contains('مبيعات غير متصلة'));
    expect(source, contains("value: '—'"));
    expect(source, isNot(contains("value: '١٬٢٤٠'")));
    expect(source, isNot(contains("value: '٢٨٫٥ ألف'")));
    expect(source, isNot(contains('Icons.verified_rounded')));
    expect(source, contains('معاينة البث'));
  });

  test(
      'farmer studio labels broadcast chat stock and verification as demo/local',
      () {
    final source = File('lib/features/farmer/farmer_studio_screen.dart')
        .readAsStringSync();
    expect(source, contains('وضع بائع تجريبي'));
    expect(source, contains('لا يتم بث أو بيع عبر الخادم'));
    expect(source, contains('معاينة بث مباشر'));
    expect(source, contains('معاينة محلية'));
    expect(source, contains('مثال محلي:'));
    expect(source, contains('مخزون تجريبي'));
    expect(source, isNot(contains('حساب مزارع موثّق')));
    expect(source, isNot(contains("LiveChip(label: 'على الهواء')")));
  });

  test(
      'role screen offers optional Arabic spoken guidance and truthful seller scope',
      () {
    final source = File('lib/features/onboarding/role_selection_screen.dart')
        .readAsStringSync();
    expect(source, contains("ValueKey('role-audio-guide')"));
    expect(source, contains("label: 'اسمع الخيارات'"));
    expect(source, contains('معاينة بث محلية'));
    expect(source, contains('معاينة دفع فقط'));
    expect(source, isNot(contains("'محفظة أو دفع صديق'")));
  });
}
