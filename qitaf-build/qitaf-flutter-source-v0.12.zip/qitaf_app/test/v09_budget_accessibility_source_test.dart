import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('payment heading no longer implies a real friend-payment send', () {
    final source =
        File('lib/features/checkout/checkout_flow.dart').readAsStringSync();
    expect(source, contains('اختر مسارًا تجريبيًا للمعاينة'));
    expect(source, contains('لا يتم إرسال أو خصم أي مبلغ في هذه النسخة'));
    expect(source, isNot(contains('أو إرسال طلب آمن إلى صديق')));
  });

  test('home basket exposes accessible budget usage meter', () {
    final source =
        File('lib/features/basket/home_basket_screen.dart').readAsStringSync();
    expect(source, contains("ValueKey('budget-meter-card')"));
    expect(source, contains("ValueKey('budget-usage-text')"));
    expect(source, contains("ValueKey('budget-progress')"));
    expect(source, contains("label: 'مؤشر الميزانية'"));
    expect(source, contains('المتبقي من الميزانية'));
    expect(source, contains('التجاوز عن الميزانية'));
  });
}
