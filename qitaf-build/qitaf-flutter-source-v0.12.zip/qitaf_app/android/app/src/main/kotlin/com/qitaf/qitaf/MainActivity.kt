package com.qitaf.qitaf

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
