#!/usr/bin/env python3
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / 'android'
MANIFEST = ANDROID / 'app/src/main/AndroidManifest.xml'

if not MANIFEST.exists():
    raise SystemExit('Android scaffold is missing. Run flutter create before this script.')

text = MANIFEST.read_text(encoding='utf-8')
permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
]
for permission in reversed(permissions):
    if permission not in text:
        text = text.replace('<application', f'    {permission}\n\n    <application', 1)

if '<uses-feature android:name="android.hardware.camera.any" android:required="false" />' not in text:
    text = text.replace(
        '<application',
        '    <uses-feature android:name="android.hardware.camera.any" android:required="false" />\n\n    <application',
        1,
    )

text = re.sub(r'android:label="[^"]*"', 'android:label="@string/app_name"', text, count=1)
if 'android:screenOrientation=' not in text:
    text = text.replace(
        'android:exported="true"',
        'android:exported="true"\n            android:screenOrientation="portrait"',
        1,
    )
# Android 11+ text-to-speech engine visibility, without extra device permissions.
if 'android.intent.action.TTS_SERVICE' not in text:
    intent = '<intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>'
    if '</queries>' in text:
        text = text.replace('</queries>', intent + '\n    </queries>', 1)
    else:
        text = text.replace('</manifest>', '<queries>' + intent + '</queries>\n</manifest>')
MANIFEST.write_text(text, encoding='utf-8')

values = ANDROID / 'app/src/main/res/values'
values_ar = ANDROID / 'app/src/main/res/values-ar'
values.mkdir(parents=True, exist_ok=True)
values_ar.mkdir(parents=True, exist_ok=True)
(values / 'strings.xml').write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">Qitaf</string>\n</resources>\n',
    encoding='utf-8',
)
(values_ar / 'strings.xml').write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">قِطاف</string>\n</resources>\n',
    encoding='utf-8',
)

icons = ROOT / 'tool/android_icons'
res = ANDROID / 'app/src/main/res'
for source in icons.glob('mipmap-*/ic_launcher.png'):
    destination = res / source.parent.name / 'ic_launcher.png'
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

# Use the same icon for round launchers where generated resources reference it.
for source in icons.glob('mipmap-*/ic_launcher.png'):
    destination = res / source.parent.name / 'ic_launcher_round.png'
    shutil.copy2(source, destination)

print('Android configuration applied successfully.')
