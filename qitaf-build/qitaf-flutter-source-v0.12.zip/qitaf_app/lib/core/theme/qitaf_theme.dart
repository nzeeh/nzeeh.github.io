import 'package:flutter/material.dart';

abstract final class QitafColors {
  static const burgundy = Color(0xFF7A1F2B);
  static const burgundyDark = Color(0xFF5F1D29);
  static const terraceGreen = Color(0xFF2E6A4D);
  static const gold = Color(0xFFC6983B);
  static const ivory = Color(0xFFFFF9EF);
  static const sand = Color(0xFFF1E2CE);
  static const charcoal = Color(0xFF1E1B1A);
  static const muted = Color(0xFF746D69);
  static const live = Color(0xFFFF3B4F);
}

ThemeData buildQitafTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: QitafColors.burgundy,
    brightness: Brightness.light,
    primary: QitafColors.burgundy,
    secondary: QitafColors.terraceGreen,
    surface: QitafColors.ivory,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: QitafColors.ivory,
    fontFamily: 'sans-serif',
    appBarTheme: const AppBarTheme(
      backgroundColor: QitafColors.ivory,
      foregroundColor: QitafColors.charcoal,
      centerTitle: true,
      elevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFE8DFD4)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: QitafColors.burgundy, width: 1.5),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: QitafColors.burgundy,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: QitafColors.burgundy,
        minimumSize: const Size.fromHeight(52),
        side: const BorderSide(color: QitafColors.burgundy),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    ),
  );
}
