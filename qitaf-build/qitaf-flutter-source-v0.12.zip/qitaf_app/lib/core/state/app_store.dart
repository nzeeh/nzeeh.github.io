import 'dart:convert';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';
import '../models/user_role.dart';
export '../models/user_role.dart';

/// Local demo state only. No payment credentials, addresses or auth secrets here.
class AppStore extends ChangeNotifier {
  static const _roleKey = 'qitaf_user_role';
  static const _cartKey = 'qitaf_cart_v3';
  static const _savedKey = 'qitaf_saved_products_v3';
  static const deliveryRiyals = 1200;
  final List<CartItem> _cart = [];
  final Set<String> _likedProductIds = {};
  final Set<String> _savedProductIds = {};
  QitafUserRole? _selectedRole;
  bool _isReady = false;
  bool _disposed = false;
  Future<void> _writes = Future<void>.value();
  String? storageWarning;
  String? lastCartError;

  QitafUserRole? get selectedRole => _selectedRole;
  bool get isReady => _isReady;
  bool get isSeller => _selectedRole == QitafUserRole.seller;
  bool get isBuyer => _selectedRole == QitafUserRole.buyer;
  List<CartItem> get cart => List.unmodifiable(_cart);
  List<Product> get savedProducts =>
      demoProducts.where((p) => isSaved(p.id)).toList();
  int get cartCount => _cart.fold(0, (n, row) => n + row.selection.quantity);
  int get subtotalMinor =>
      _cart.fold(0, (n, row) => n + (row.total * 100).round());
  double get subtotal => subtotalMinor / 100;
  double get deliveryFee => _cart.isEmpty ? 0 : deliveryRiyals.toDouble();
  double get total => subtotal + deliveryFee;
  Future<void> get saved => _writes;

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> initialize() async {
    if (_isReady) {
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      _selectedRole = qitafRoleFromStorage(prefs.getString(_roleKey));
      _savedProductIds.addAll((prefs.getStringList(_savedKey) ?? [])
          .where((id) => demoProducts.any((p) => p.id == id)));
      final raw = prefs.getString(_cartKey);
      if (raw != null) {
        final rows = jsonDecode(raw);
        if (rows is List) {
          for (final row in rows) {
            try {
              if (row is! Map) {
                continue;
              }
              final product = demoProducts.firstWhere((p) => p.id == row['id']);
              ChoiceOption option(List<ChoiceOption> options, String key) =>
                  options.firstWhere((o) => o.label == row[key]);
              final quantity = row['quantity'];
              if (quantity is! int || quantity < 1) {
                continue;
              }
              final selection = ProductSelection(
                weight: option(product.weightOptions, 'weight'),
                quality: option(product.qualityOptions, 'quality'),
                ripeness: option(product.ripenessOptions, 'ripeness'),
                packaging: option(product.packagingOptions, 'packaging'),
                quantity: quantity,
              );
              final candidate = [
                ..._cart,
                CartItem(product: product, selection: selection)
              ];
              if (_validStock(candidate)) {
                _merge(_cart, product, selection);
              }
            } catch (_) {
              /* Ignore obsolete/corrupt variants, never trust saved prices. */
            }
          }
        }
      }
    } catch (_) {
      storageWarning =
          'تعذر استعادة بعض البيانات المحفوظة. يمكنك متابعة التجربة.';
    } finally {
      _isReady = true;
      _notify();
    }
  }

  Future<void> selectRole(QitafUserRole role) async {
    _selectedRole = role;
    _isReady = true;
    _notify();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_roleKey, role.storageValue);
    } catch (_) {
      storageWarning = 'لم يُحفظ اختيارك على الجهاز.';
      _notify();
    }
  }

  Future<void> clearRole() async {
    _selectedRole = null;
    _notify();
    try {
      final p = await SharedPreferences.getInstance();
      await p.remove(_roleKey);
    } catch (_) {
      storageWarning = 'تعذر تحديث الاختيار المحفوظ.';
      _notify();
    }
  }

  bool isLiked(String id) => _likedProductIds.contains(id);
  void toggleLike(String id) {
    if (!_likedProductIds.add(id)) {
      _likedProductIds.remove(id);
    }
    _notify();
  }

  bool isSaved(String id) => _savedProductIds.contains(id);
  void toggleSaved(String id) {
    if (!demoProducts.any((p) => p.id == id)) {
      return;
    }
    if (!_savedProductIds.add(id)) {
      _savedProductIds.remove(id);
    }
    _persist();
    _notify();
  }

  bool addToCart(Product product, ProductSelection selection) =>
      addBundle([CartItem(product: product, selection: selection)]);

  /// Atomic local addition: validate the whole bundle before mutating the cart.
  /// Production checkout must independently revalidate on the server.
  bool addBundle(List<CartItem> rows, {int? budgetRiyals}) {
    lastCartError = null;
    final candidate = _cart
        .map((r) => CartItem(product: r.product, selection: r.selection))
        .toList();
    for (final row in rows) {
      if (row.selection.quantity < 1 || row.selection.quantity > 10000) {
        lastCartError = 'الكمية غير صحيحة.';
        return false;
      }
      _merge(candidate, row.product, row.selection);
    }
    if (!_validStock(candidate)) {
      lastCartError = 'الكمية المطلوبة أكبر من المخزون التجريبي المتاح.';
      return false;
    }
    final totalMinor =
        candidate.fold<int>(0, (n, r) => n + (r.total * 100).round()) +
            (candidate.isEmpty ? 0 : deliveryRiyals * 100);
    if (budgetRiyals != null && totalMinor > budgetRiyals * 100) {
      lastCartError = 'إجمالي السلة مع التوصيل يتجاوز الميزانية. راجع الكميات.';
      return false;
    }
    _cart
      ..clear()
      ..addAll(candidate);
    _persist();
    _notify();
    return true;
  }

  double reservedUnits(String productId) =>
      _cart.where((r) => r.product.id == productId).fold(
          0.0,
          (n, r) =>
              n +
              r.selection.weight.quantityInBaseUnits * r.selection.quantity);

  bool _validStock(List<CartItem> rows) {
    final used = <String, double>{};
    for (final row in rows) {
      final units =
          row.selection.weight.quantityInBaseUnits * row.selection.quantity;
      if (units <= 0 || !units.isFinite || row.selection.quantity < 1) {
        return false;
      }
      used[row.product.id] = (used[row.product.id] ?? 0) + units;
      if (used[row.product.id]! > row.product.stock + 0.000001) {
        return false;
      }
    }
    return true;
  }

  void _merge(
      List<CartItem> list, Product product, ProductSelection selection) {
    final index = list.indexWhere((r) =>
        r.product.id == product.id && _sameVariant(r.selection, selection));
    if (index < 0) {
      list.add(CartItem(product: product, selection: selection));
    } else {
      list[index].selection = selection.copyWith(
          quantity: list[index].selection.quantity + selection.quantity);
    }
  }

  bool increment(CartItem item) =>
      addToCart(item.product, item.selection.copyWith(quantity: 1));
  void decrement(CartItem item) {
    if (item.selection.quantity <= 1) {
      _cart.remove(item);
    } else {
      item.selection =
          item.selection.copyWith(quantity: item.selection.quantity - 1);
    }
    _persist();
    _notify();
  }

  void remove(CartItem item) {
    _cart.remove(item);
    _persist();
    _notify();
  }

  void clearCart() {
    _cart.clear();
    _persist();
    _notify();
  }

  bool _sameVariant(ProductSelection a, ProductSelection b) =>
      a.weight.label == b.weight.label &&
      a.quality.label == b.quality.label &&
      a.ripeness.label == b.ripeness.label &&
      a.packaging.label == b.packaging.label;

  void _persist() {
    final payload = jsonEncode(_cart
        .map((r) => {
              'id': r.product.id,
              'quantity': r.selection.quantity,
              'weight': r.selection.weight.label,
              'quality': r.selection.quality.label,
              'ripeness': r.selection.ripeness.label,
              'packaging': r.selection.packaging.label,
            })
        .toList());
    final savedIds = _savedProductIds.toList();
    // Serialize writes: a slow old save must not overwrite a more recent edit.
    _writes = _writes.then((_) async {
      try {
        final p = await SharedPreferences.getInstance();
        final a = await p.setString(_cartKey, payload);
        final b = await p.setStringList(_savedKey, savedIds);
        if (!a || !b) {
          throw StateError('local save failed');
        }
      } catch (_) {
        storageWarning = 'تغييراتك تعمل الآن، لكن تعذر حفظها لإعادة الفتح.';
        _notify();
      }
    });
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}

class AppScope extends InheritedNotifier<AppStore> {
  const AppScope({super.key, required AppStore store, required super.child})
      : super(notifier: store);
  static AppStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope is missing above this context.');
    return scope!.notifier!;
  }
}
