enum QitafUserRole { buyer, seller }

extension QitafUserRoleX on QitafUserRole {
  String get storageValue => switch (this) {
        QitafUserRole.buyer => 'buyer',
        QitafUserRole.seller => 'seller',
      };

  String get arabicLabel => switch (this) {
        QitafUserRole.buyer => 'مشتري',
        QitafUserRole.seller => 'مزارع / بائع',
      };
}

QitafUserRole? qitafRoleFromStorage(String? value) => switch (value) {
      'buyer' => QitafUserRole.buyer,
      'seller' => QitafUserRole.seller,
      _ => null,
    };
