class ChoiceOption {
  const ChoiceOption({
    required this.label,
    this.priceMultiplier = 1,
    this.quantityInBaseUnits = 1,
  });

  final String label;
  final double priceMultiplier;
  // Physical quantity is separate from price discounts. A 10 kg box is still 10 kg.
  final double quantityInBaseUnits;
}

class Product {
  const Product({
    required this.id,
    required this.name,
    required this.shortDescription,
    required this.farmerName,
    required this.location,
    required this.feedAsset,
    required this.productAsset,
    required this.basePrice,
    required this.unitLabel,
    required this.stock,
    required this.likes,
    required this.viewers,
    required this.weightOptions,
    required this.qualityOptions,
    required this.ripenessOptions,
    required this.packagingOptions,
    this.isLive = true,
    this.isVerified = false,
  });

  final String id;
  final String name;
  final String shortDescription;
  final String farmerName;
  final String location;
  final String feedAsset;
  final String productAsset;
  final double basePrice;
  final String unitLabel;
  final int stock;
  final int likes;
  final int viewers;
  final List<ChoiceOption> weightOptions;
  final List<ChoiceOption> qualityOptions;
  final List<ChoiceOption> ripenessOptions;
  final List<ChoiceOption> packagingOptions;
  final bool isLive;
  final bool isVerified;
}

class ProductSelection {
  const ProductSelection({
    required this.weight,
    required this.quality,
    required this.ripeness,
    required this.packaging,
    required this.quantity,
  });

  final ChoiceOption weight;
  final ChoiceOption quality;
  final ChoiceOption ripeness;
  final ChoiceOption packaging;
  final int quantity;

  double unitTotal(Product product) {
    return (product.basePrice *
                weight.priceMultiplier *
                quality.priceMultiplier *
                ripeness.priceMultiplier *
                packaging.priceMultiplier *
                100)
            .round() /
        100;
  }

  double lineTotal(Product product) => unitTotal(product) * quantity;

  ProductSelection copyWith({
    ChoiceOption? weight,
    ChoiceOption? quality,
    ChoiceOption? ripeness,
    ChoiceOption? packaging,
    int? quantity,
  }) {
    return ProductSelection(
      weight: weight ?? this.weight,
      quality: quality ?? this.quality,
      ripeness: ripeness ?? this.ripeness,
      packaging: packaging ?? this.packaging,
      quantity: quantity ?? this.quantity,
    );
  }
}

class CartItem {
  CartItem({
    required this.product,
    required this.selection,
  });

  final Product product;
  ProductSelection selection;

  double get total => selection.lineTotal(product);
}

const demoProducts = <Product>[
  Product(
    id: 'tomato-001',
    name: 'طماطم بلدية طازجة',
    shortDescription: 'قُطفت هذا الصباح من مدرجات وادي ظهر',
    farmerName: 'مزرعة آل النعماني',
    location: 'وادي ظهر، صنعاء',
    feedAsset: 'assets/images/tomato_farm.jpg',
    productAsset: 'assets/images/tomato_product.jpg',
    basePrice: 900,
    unitLabel: 'كجم',
    stock: 86,
    likes: 0,
    viewers: 0,
    weightOptions: [
      ChoiceOption(label: '1 كجم'),
      ChoiceOption(label: '3 كجم', priceMultiplier: 3, quantityInBaseUnits: 3),
      ChoiceOption(label: '5 كجم', priceMultiplier: 5, quantityInBaseUnits: 5),
      ChoiceOption(
          label: 'صندوق 10 كجم', priceMultiplier: 9.2, quantityInBaseUnits: 10),
    ],
    qualityOptions: [
      ChoiceOption(label: 'فرز ممتاز', priceMultiplier: 1.12),
      ChoiceOption(label: 'فرز اقتصادي'),
    ],
    ripenessOptions: [
      ChoiceOption(label: 'أخضر'),
      ChoiceOption(label: 'نصف ناضج'),
      ChoiceOption(label: 'أحمر ناضج', priceMultiplier: 1.05),
    ],
    packagingOptions: [
      ChoiceOption(label: 'كيس شبكي'),
      ChoiceOption(label: 'صندوق كرتون', priceMultiplier: 1.08),
    ],
  ),
  Product(
    id: 'mango-001',
    name: 'مانجو تهامي',
    shortDescription: 'حبات كبيرة من المزرعة مباشرة',
    farmerName: 'مزرعة تهامة الخضراء',
    location: 'الحديدة، باجل',
    feedAsset: 'assets/images/mango_orchard.jpg',
    productAsset: 'assets/images/mango_product.jpg',
    basePrice: 1600,
    unitLabel: 'كجم',
    stock: 140,
    likes: 0,
    viewers: 0,
    weightOptions: [
      ChoiceOption(label: '1 كجم'),
      ChoiceOption(
          label: 'صندوق 5 كجم', priceMultiplier: 4.7, quantityInBaseUnits: 5),
      ChoiceOption(
          label: 'صندوق 10 كجم', priceMultiplier: 9, quantityInBaseUnits: 10),
    ],
    qualityOptions: [
      ChoiceOption(label: 'ممتاز للتقديم', priceMultiplier: 1.18),
      ChoiceOption(label: 'اقتصادي للعصير'),
    ],
    ripenessOptions: [
      ChoiceOption(label: 'جاهز للأكل'),
      ChoiceOption(label: 'قابل للشحن'),
    ],
    packagingOptions: [
      ChoiceOption(label: 'صندوق مهوي'),
      ChoiceOption(label: 'تغليف هدية', priceMultiplier: 1.12),
    ],
  ),
  Product(
    id: 'coffee-001',
    name: 'بن يمني قطفة الموسم',
    shortDescription: 'حبوب حمراء من مدرجات حراز',
    farmerName: 'مزارعو حراز التعاونية',
    location: 'حراز، صنعاء',
    feedAsset: 'assets/images/coffee_terraces.jpg',
    productAsset: 'assets/images/coffee_product.jpg',
    basePrice: 7800,
    unitLabel: 'كجم',
    stock: 33,
    likes: 0,
    viewers: 0,
    weightOptions: [
      ChoiceOption(
          label: '250 جم', priceMultiplier: 0.25, quantityInBaseUnits: 0.25),
      ChoiceOption(
          label: '500 جم', priceMultiplier: 0.5, quantityInBaseUnits: 0.5),
      ChoiceOption(label: '1 كجم'),
    ],
    qualityOptions: [
      ChoiceOption(label: 'مختص فاخر', priceMultiplier: 1.25),
      ChoiceOption(label: 'درجة أولى'),
    ],
    ripenessOptions: [
      ChoiceOption(label: 'حب كامل'),
      ChoiceOption(label: 'مطحون ناعم'),
      ChoiceOption(label: 'مطحون وسط'),
    ],
    packagingOptions: [
      ChoiceOption(label: 'كيس محكم'),
      ChoiceOption(label: 'علبة هدية', priceMultiplier: 1.15),
    ],
  ),
  Product(
    id: 'honey-001',
    name: 'عسل سدر من المنحل',
    shortDescription: 'تعبئة مباشرة أمامك — بيانات تجريبية من المنحل',
    farmerName: 'مناحل الوادي',
    location: 'دوعن، حضرموت',
    feedAsset: 'assets/images/honey_farm.jpg',
    productAsset: 'assets/images/honey_product.jpg',
    basePrice: 22000,
    unitLabel: 'كجم',
    stock: 18,
    likes: 0,
    viewers: 0,
    weightOptions: [
      ChoiceOption(
          label: '250 جم', priceMultiplier: 0.25, quantityInBaseUnits: 0.25),
      ChoiceOption(
          label: '500 جم', priceMultiplier: 0.5, quantityInBaseUnits: 0.5),
      ChoiceOption(label: '1 كجم'),
    ],
    qualityOptions: [
      ChoiceOption(label: 'سدر ممتاز', priceMultiplier: 1.2),
      ChoiceOption(label: 'سدر طبيعي'),
    ],
    ripenessOptions: [
      ChoiceOption(label: 'قوام كثيف'),
      ChoiceOption(label: 'قوام متوسط'),
    ],
    packagingOptions: [
      ChoiceOption(label: 'عبوة زجاج'),
      ChoiceOption(label: 'عبوة سفر محكمة', priceMultiplier: 1.08),
    ],
  ),
];
