import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/state/app_store.dart';
import 'core/theme/qitaf_theme.dart';
import 'features/onboarding/role_selection_screen.dart';
import 'widgets/common_widgets.dart';
import 'widgets/qitaf_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QitafApp());
}

class QitafApp extends StatefulWidget {
  const QitafApp({super.key});

  @override
  State<QitafApp> createState() => _QitafAppState();
}

class _QitafAppState extends State<QitafApp> {
  late final AppStore store;

  @override
  void initState() {
    super.initState();
    store = AppStore();
    store.initialize();
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      store: store,
      child: MaterialApp(
        title: 'قِطاف',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: buildQitafTheme(),
        home: const QitafRoleGate(),
      ),
    );
  }
}

class QitafRoleGate extends StatelessWidget {
  const QitafRoleGate({super.key});

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);

    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.isReady) {
          return const _QitafSplashScreen();
        }

        final role = store.selectedRole;
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 320),
          switchInCurve: Curves.easeOut,
          switchOutCurve: Curves.easeIn,
          child: role == null
              ? const RoleSelectionScreen(key: ValueKey('role-picker'))
              : QitafShell(
                  key: ValueKey('${role.storageValue}-shell'),
                  role: role,
                ),
        );
      },
    );
  }
}

class _QitafSplashScreen extends StatelessWidget {
  const _QitafSplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: QitafColors.burgundy,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            QitafWordmark(onDark: true),
            SizedBox(height: 24),
            SizedBox(
              width: 30,
              height: 30,
              child: CircularProgressIndicator(
                color: Colors.white,
                strokeWidth: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
