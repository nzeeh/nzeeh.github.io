import 'package:flutter/material.dart';

import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';

class SellerHomeScreen extends StatelessWidget {
  const SellerHomeScreen({
    super.key,
    required this.onStartStudio,
    required this.onOpenBuyerFeed,
  });

  final VoidCallback onStartStudio;
  final VoidCallback onOpenBuyerFeed;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 132),
        children: [
          Row(
            children: [
              const QitafWordmark(),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(
                  color: const Color(0xFFE7F1EB),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(color: const Color(0xFFBDD7C7)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.agriculture_rounded,
                      color: QitafColors.terraceGreen,
                      size: 17,
                    ),
                    SizedBox(width: 5),
                    Text(
                      'وضع البائع',
                      style: TextStyle(
                        color: QitafColors.terraceGreen,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const Text(
            'أهلًا بك يا مزارع 👋',
            style: TextStyle(
              color: QitafColors.charcoal,
              fontSize: 26,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'صوّر محصولك وجهّز عرضه التجريبي؛ الطلبات الحقيقية غير متصلة بعد.',
            style: TextStyle(
              color: QitafColors.muted,
              fontSize: 14,
              height: 1.55,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 18),
          _LiveHero(onTap: onStartStudio),
          const SizedBox(height: 16),
          const Row(
            children: [
              Expanded(
                child: _MetricCard(
                  icon: Icons.receipt_long_rounded,
                  value: '—',
                  label: 'طلبات غير متصلة',
                  accent: QitafColors.burgundy,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: _MetricCard(
                  icon: Icons.visibility_rounded,
                  value: '—',
                  label: 'مشاهدات غير متصلة',
                  accent: QitafColors.terraceGreen,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: _MetricCard(
                  icon: Icons.payments_rounded,
                  value: '—',
                  label: 'مبيعات غير متصلة',
                  accent: QitafColors.gold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const SectionTitle(
            title: 'ماذا تريد أن تفعل؟',
            subtitle: 'اختر صورة واحدة فقط، وسنرشدك خطوة بخطوة.',
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.18,
            children: [
              _ActionCard(
                icon: Icons.videocam_rounded,
                title: 'معاينة البث',
                subtitle: 'افتح الكاميرا محليًا',
                color: QitafColors.live,
                onTap: onStartStudio,
              ),
              _ActionCard(
                icon: Icons.mic_rounded,
                title: 'أضف منتجًا',
                subtitle: 'قل الاسم والسعر بصوتك',
                color: QitafColors.terraceGreen,
                onTap: onStartStudio,
              ),
              _ActionCard(
                icon: Icons.inventory_2_rounded,
                title: 'منتجاتي',
                subtitle: 'السعر والكمية التجريبية',
                color: QitafColors.burgundy,
                onTap: () => _showComingSoon(context, 'إدارة المنتجات'),
              ),
              _ActionCard(
                icon: Icons.local_shipping_rounded,
                title: 'الطلبات',
                subtitle: 'غير متصلة بخدمة توصيل',
                color: QitafColors.gold,
                onTap: () => _showComingSoon(context, 'إدارة الطلبات'),
              ),
            ],
          ),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: const Color(0xFFE8DED2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: QitafColors.sand,
                      child: Icon(
                        Icons.lightbulb_rounded,
                        color: QitafColors.gold,
                      ),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'ثلاث خطوات لتجهيز العرض',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                const _SellerStep(
                  number: '١',
                  title: 'وجّه الكاميرا إلى المحصول',
                ),
                const _SellerStep(
                  number: '٢',
                  title: 'قل السعر والكمية بصوتك',
                ),
                const _SellerStep(
                  number: '٣',
                  title: 'اضغط الزر الأحمر لمعاينة العرض',
                ),
                const SizedBox(height: 4),
                OutlinedButton.icon(
                  onPressed: onOpenBuyerFeed,
                  icon: const Icon(Icons.play_circle_outline_rounded),
                  label: const Text('شاهد ما يراه المشترون'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showComingSoon(BuildContext context, String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$feature غير متصلة بالخادم في هذه النسخة.'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}

class _LiveHero extends StatelessWidget {
  const _LiveHero({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [QitafColors.burgundy, QitafColors.burgundyDark],
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [
          BoxShadow(
            color: Color(0x338B2D3C),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: QitafColors.live,
                  borderRadius: BorderRadius.circular(99),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.circle, color: Colors.white, size: 8),
                    SizedBox(width: 5),
                    Text(
                      'معاينة من المزرعة',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              const Icon(
                Icons.agriculture_rounded,
                color: Colors.white70,
                size: 38,
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'صوّر محصولك الآن\nواجعل السعر يظهر على المعاينة',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              height: 1.3,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'لا تحتاج إلى الكتابة. تحدث فقط، وقِطاف يرتب البطاقة.',
            style: TextStyle(
              color: Colors.white70,
              height: 1.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 17),
          FilledButton.icon(
            onPressed: onTap,
            style: FilledButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: QitafColors.burgundy,
            ),
            icon: const Icon(Icons.videocam_rounded),
            label: const Text('افتح معاينة الكاميرا'),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.accent,
  });

  final IconData icon;
  final String value;
  final String label;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 13),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(21),
      ),
      child: Column(
        children: [
          Icon(icon, color: accent, size: 24),
          const SizedBox(height: 7),
          FittedBox(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: QitafColors.muted,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.13),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Icon(icon, color: color, size: 27),
              ),
              const Spacer(),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: QitafColors.muted,
                  fontSize: 11,
                  height: 1.4,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SellerStep extends StatelessWidget {
  const _SellerStep({required this.number, required this.title});

  final String number;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: QitafColors.terraceGreen,
            child: Text(
              number,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: QitafColors.charcoal,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
