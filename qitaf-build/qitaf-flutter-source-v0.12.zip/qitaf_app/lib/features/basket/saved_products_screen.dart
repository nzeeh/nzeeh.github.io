import 'package:flutter/material.dart';
import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';
import '../product/product_sheet.dart';

class SavedProductsScreen extends StatelessWidget {
  const SavedProductsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final products = store.savedProducts;
    return Scaffold(
        appBar: AppBar(title: const Text('قِطفاتي المحفوظة')),
        body: products.isEmpty
            ? const Center(
                child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.bookmark_border_rounded,
                          color: QitafColors.burgundy, size: 70),
                      SizedBox(height: 20),
                      Text('احتفظ بالمنتج الذي أعجبك',
                          style: TextStyle(
                              fontSize: 23, fontWeight: FontWeight.w900),
                          textAlign: TextAlign.center),
                      SizedBox(height: 12),
                      Text(
                          'اضغط «حفظ» في المقاطع، ثم عُد إليه هنا. يبقى محفوظًا على هذا الجهاز بعد إغلاق التطبيق.',
                          textAlign: TextAlign.center),
                    ])))
            : ListView.separated(
                padding: const EdgeInsets.all(18),
                itemCount: products.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) {
                  final p = products[i];
                  return Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(12),
                        leading: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.asset(p.productAsset,
                                width: 58, height: 58, fit: BoxFit.cover)),
                        title: Text(p.name,
                            style:
                                const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text(
                            '${formatMoney(p.basePrice)} ريال / ${p.unitLabel}\nسعر تجريبي'),
                        onTap: () => showProductConfigurator(context, p),
                        trailing: IconButton(
                            tooltip: 'إزالة من المحفوظات',
                            onPressed: () => store.toggleSaved(p.id),
                            icon: const Icon(Icons.bookmark_remove_outlined,
                                color: QitafColors.burgundy)),
                      ));
                },
              ));
  }
}
