import 'package:flutter/material.dart';
import '../../core/models/product.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';
import '../product/product_sheet.dart';
import '../basket/home_basket_screen.dart';
import '../basket/saved_products_screen.dart';

class MarketScreen extends StatefulWidget {
  const MarketScreen({super.key});

  @override
  State<MarketScreen> createState() => _MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  String query = '';
  String category = 'الكل';

  @override
  Widget build(BuildContext context) {
    final products = demoProducts.where((product) {
      final matchesQuery =
          product.name.contains(query) || product.location.contains(query);
      final matchesCategory =
          category == 'الكل' || _categoryFor(product) == category;
      return matchesQuery && matchesCategory;
    }).toList();

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const QitafWordmark(),
                      const Spacer(),
                      IconButton.filledTonal(
                        onPressed: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) => const SavedProductsScreen())),
                        tooltip: 'قِطفاتي المحفوظة',
                        icon: const Icon(Icons.bookmarks_outlined),
                      ),
                    ],
                  ),
                  const SizedBox(height: 22),
                  const SectionTitle(
                    title: 'سوق المحاصيل',
                    subtitle: 'منتجات ومزارع توضيحية • نسخة تجريبية',
                  ),
                  const SizedBox(height: 16),
                  const HomeBasketBanner(),
                  const SizedBox(height: 18),
                  TextField(
                    onChanged: (value) => setState(() => query = value.trim()),
                    decoration: const InputDecoration(
                      hintText: 'ابحث عن طماطم، عسل، مانجو أو مدينة',
                      prefixIcon: Icon(Icons.search_rounded),
                      suffixIcon: Icon(Icons.mic_none_rounded,
                          color: QitafColors.burgundy),
                    ),
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    height: 44,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: ['الكل', 'خضروات', 'فواكه', 'قهوة', 'عسل']
                          .map((label) => Padding(
                                padding:
                                    const EdgeInsetsDirectional.only(end: 8),
                                child: ChoicePill(
                                  label: label,
                                  selected: category == label,
                                  onTap: () => setState(() => category = label),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 18),
                ],
              ),
            ),
          ),
          if (products.isEmpty)
            const SliverToBoxAdapter(
                child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                        'لم نجد هذا المحصول. جرّب اسمًا آخر أو فئة أخرى.',
                        textAlign: TextAlign.center))),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 130),
            sliver: SliverGrid.builder(
              itemCount: products.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.69,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (context, index) =>
                  _ProductCard(product: products[index]),
            ),
          ),
        ],
      ),
    );
  }

  String _categoryFor(Product product) {
    if (product.id.startsWith('tomato')) return 'خضروات';
    if (product.id.startsWith('mango')) return 'فواكه';
    if (product.id.startsWith('coffee')) return 'قهوة';
    return 'عسل';
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: () => showProductConfigurator(context, product),
        borderRadius: BorderRadius.circular(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(22)),
                    child: Image.asset(product.productAsset, fit: BoxFit.cover),
                  ),
                  PositionedDirectional(
                    top: 10,
                    start: 10,
                    child: product.isLive
                        ? const LiveChip(label: 'تجريبي')
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 11, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 15)),
                  const SizedBox(height: 4),
                  Text(product.location,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: QitafColors.muted, fontSize: 12)),
                  const SizedBox(height: 8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          '${formatMoney(product.basePrice)} ريال',
                          style: const TextStyle(
                              color: QitafColors.burgundy,
                              fontSize: 17,
                              fontWeight: FontWeight.w900),
                        ),
                      ),
                      Container(
                        width: 34,
                        height: 34,
                        decoration: const BoxDecoration(
                            color: QitafColors.sand, shape: BoxShape.circle),
                        child: const Icon(Icons.add_shopping_cart_rounded,
                            color: QitafColors.burgundy, size: 19),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
