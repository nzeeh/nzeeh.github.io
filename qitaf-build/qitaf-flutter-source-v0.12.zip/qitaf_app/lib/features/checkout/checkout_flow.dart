import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/state/app_store.dart';
import '../../core/services/read_aloud.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';

class RecipientAddressScreen extends StatefulWidget {
  const RecipientAddressScreen({super.key, this.forSomeoneElse = false});

  final bool forSomeoneElse;

  @override
  State<RecipientAddressScreen> createState() => _RecipientAddressScreenState();
}

class _RecipientAddressScreenState extends State<RecipientAddressScreen> {
  bool forMe = true;
  bool hidePrice = false;
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final cityController = TextEditingController();
  final districtController = TextEditingController();
  final streetController = TextEditingController();
  final landmarkController = TextEditingController();
  final detailsController = TextEditingController();
  final giftController = TextEditingController();

  @override
  void initState() {
    super.initState();
    forMe = !widget.forSomeoneElse;
    hidePrice = widget.forSomeoneElse;
  }

  @override
  void dispose() {
    for (final controller in [
      nameController,
      phoneController,
      cityController,
      districtController,
      streetController,
      landmarkController,
      detailsController,
      giftController,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المستلم والعنوان')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          const SectionTitle(
            title: 'لمن سنوصل القطفة؟',
            subtitle: 'تجربة محلية فقط. يمكنك الشراء لنفسك أو لشخص آخر.',
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                  child: _recipientChoice(true, Icons.person_rounded, 'لي أنا',
                      'إلى عنواني المحفوظ')),
              const SizedBox(width: 10),
              Expanded(
                  child: _recipientChoice(false, Icons.card_giftcard_rounded,
                      'لشخص آخر', 'هدية أو طلب للعائلة')),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFFFFF1D9), Color(0xFFF8E4C3)]),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0xFFE8C789)),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: QitafColors.burgundy,
                  child: Icon(Icons.mic_rounded, color: Colors.white),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('اكتب العنوان أو اسمع الإرشاد',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 16)),
                      Text(
                          'الإملاء الصوتي غير متصل بعد؛ لن يشغّل هذا الزر الميكروفون.',
                          style:
                              TextStyle(color: QitafColors.muted, height: 1.4)),
                    ],
                  ),
                ),
                Expanded(
                  child: ReadAloudButton(
                    key: ValueKey('address-audio-guide'),
                    label: 'اسمع الطريقة',
                    text:
                        'اكتب المحافظة أو المدينة، ثم المنطقة أو الحي، ثم الشارع وأقرب معلم معروف، وبعدها صف الباب أو المنزل باختصار. هذه النسخة لا تستمع إلى الميكروفون ولا تحفظ موقعًا حقيقيًا على الخريطة.',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          if (!forMe) ...[
            _field(nameController, 'اسم المستلم', Icons.person_outline_rounded),
            const SizedBox(height: 11),
            _field(phoneController, 'رقم هاتف المستلم', Icons.phone_outlined,
                keyboardType: TextInputType.phone),
            const SizedBox(height: 11),
          ],
          Row(
            children: [
              Expanded(
                  child: _field(cityController, 'المحافظة / المدينة',
                      Icons.location_city_outlined)),
              const SizedBox(width: 10),
              Expanded(
                  child: _field(districtController, 'المنطقة أو الحي',
                      Icons.map_outlined)),
            ],
          ),
          const SizedBox(height: 11),
          _field(streetController, 'الشارع', Icons.signpost_outlined),
          const SizedBox(height: 11),
          _field(landmarkController, 'أقرب معلم معروف', Icons.place_outlined),
          const SizedBox(height: 11),
          _field(detailsController, 'وصف الباب أو المنزل وملاحظة للسائق',
              Icons.home_outlined,
              maxLines: 2),
          const SizedBox(height: 12),
          InkWell(
            onTap: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text(
                      'معاينة فقط: الخريطة غير متصلة ولا تُحفظ إحداثيات أو موقع حقيقي.')),
            ),
            borderRadius: BorderRadius.circular(22),
            child: Container(
              height: 122,
              decoration: BoxDecoration(
                color: const Color(0xFFE7EFE8),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFBED2C3)),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CustomPaint(
                      size: const Size(double.infinity, 122),
                      painter: _MapPainter()),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999)),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.my_location_rounded,
                            color: QitafColors.burgundy),
                        SizedBox(width: 7),
                        Text('معاينة مكان الباب',
                            style: TextStyle(fontWeight: FontWeight.w900)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!forMe) ...[
            const SizedBox(height: 12),
            _field(giftController, 'رسالة هدية اختيارية', Icons.redeem_outlined,
                maxLines: 2),
            SwitchListTile.adaptive(
              value: hidePrice,
              onChanged: (value) => setState(() => hidePrice = value),
              contentPadding: EdgeInsets.zero,
              activeThumbColor: QitafColors.burgundy,
              title: const Text('إخفاء السعر عن المستلم',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('لن يظهر السعر على ورقة التسليم.'),
            ),
          ],
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _continue,
            icon: const Icon(Icons.payments_outlined),
            label: const Text('متابعة إلى الدفع'),
          ),
        ],
      ),
    );
  }

  Widget _recipientChoice(
      bool value, IconData icon, String title, String subtitle) {
    final selected = forMe == value;
    return InkWell(
      onTap: () => setState(() => forMe = value),
      borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: selected ? QitafColors.burgundy : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: selected ? QitafColors.burgundy : const Color(0xFFE6D9CA)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon,
                color: selected ? Colors.white : QitafColors.burgundy,
                size: 30),
            const SizedBox(height: 10),
            Text(title,
                style: TextStyle(
                    color: selected ? Colors.white : QitafColors.charcoal,
                    fontWeight: FontWeight.w900,
                    fontSize: 16)),
            Text(subtitle,
                style: TextStyle(
                    color: selected ? Colors.white70 : QitafColors.muted,
                    fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType? keyboardType,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
    );
  }

  void _continue() {
    if (cityController.text.trim().isEmpty ||
        phoneController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أكمل المدينة ورقم الهاتف أولًا.')),
      );
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PaymentScreen(
          recipientName: forMe ? 'أنا' : nameController.text.trim(),
          destination:
              '${cityController.text.trim()}، ${districtController.text.trim()}، ${landmarkController.text.trim()}',
        ),
      ),
    );
  }
}

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({
    super.key,
    required this.recipientName,
    required this.destination,
  });

  final String recipientName;
  final String destination;

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String method = 'wallet';
  final friendPhone = TextEditingController();

  @override
  void dispose() {
    friendPhone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('طريقة الدفع')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(22)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('ملخص التوصيل',
                    style:
                        TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                _infoRow(Icons.person_outline, 'المستلم', widget.recipientName),
                _infoRow(
                    Icons.location_on_outlined, 'العنوان', widget.destination),
                _infoRow(Icons.shopping_bag_outlined, 'عدد القطع',
                    '${store.cartCount}'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(
            title: 'من سيدفع؟',
            subtitle:
                'اختر مسارًا تجريبيًا للمعاينة: محفظة، دفع صديق، أو دفع عند الاستلام. لا يتم إرسال أو خصم أي مبلغ في هذه النسخة.',
          ),
          const SizedBox(height: 14),
          RadioGroup<String>(
            groupValue: method,
            onChanged: (next) {
              if (next != null) {
                setState(() => method = next);
              }
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _paymentChoice(
                  value: 'wallet',
                  icon: Icons.account_balance_wallet_rounded,
                  title: 'أدفع من محفظتي',
                  subtitle:
                      'محاكاة محلية فقط؛ لا تُفتح محفظة حقيقية ولا يُخصم مبلغ.',
                  badge: 'تجريبي',
                ),
                const SizedBox(height: 10),
                _paymentChoice(
                  value: 'friend',
                  icon: Icons.handshake_rounded,
                  title: 'صديقي يدفع لي',
                  subtitle:
                      'استعرض شكل طلب الدفع لصديق؛ لا يُرسل رابط فعلي في هذه النسخة.',
                  badge: 'تجريبي',
                ),
                if (method == 'friend') ...[
                  const SizedBox(height: 10),
                  TextField(
                    controller: friendPhone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'رقم هاتف تجريبي',
                      hintText: 'مثال: 77 000 0000',
                      helperText: 'لا يُرسل أي اتصال أو رسالة من هذه النسخة.',
                      prefixIcon: Icon(Icons.phone_android_rounded),
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                _paymentChoice(
                  value: 'cod',
                  icon: Icons.payments_rounded,
                  title: 'الدفع عند الاستلام',
                  subtitle:
                      'محاكاة لمسار الدفع عند الاستلام؛ التوصيل غير متصل بخدمة فعلية.',
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: QitafColors.charcoal,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Text('الإجمالي المطلوب',
                      style: TextStyle(
                          color: Colors.white70, fontWeight: FontWeight.w700)),
                ),
                Text(
                  '${formatMoney(store.total)} ريال',
                  style: const TextStyle(
                      color: Color(0xFFFFD269),
                      fontSize: 23,
                      fontWeight: FontWeight.w900),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _submit,
            icon: Icon(method == 'friend'
                ? Icons.send_rounded
                : Icons.lock_outline_rounded),
            label: Text(method == 'friend'
                ? 'معاينة طلب الدفع للصديق'
                : 'تأكيد الطلب بأمان'),
          ),
          const SizedBox(height: 10),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.verified_user_outlined,
                  size: 17, color: QitafColors.terraceGreen),
              SizedBox(width: 6),
              Text('لن يُخصم أي مبلغ في هذه النسخة التجريبية',
                  style: TextStyle(color: QitafColors.muted, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _paymentChoice({
    required String value,
    required IconData icon,
    required String title,
    required String subtitle,
    String? badge,
  }) {
    final selected = method == value;
    return InkWell(
      onTap: () => setState(() => method = value),
      borderRadius: BorderRadius.circular(22),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF0F2) : Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
              color: selected ? QitafColors.burgundy : const Color(0xFFE5DACE),
              width: selected ? 1.7 : 1),
        ),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: selected ? QitafColors.burgundy : QitafColors.sand,
                borderRadius: BorderRadius.circular(17),
              ),
              child: Icon(icon,
                  color: selected ? Colors.white : QitafColors.burgundy),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                          child: Text(title,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 16))),
                      if (badge != null) ...[
                        const SizedBox(width: 7),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                              color: QitafColors.gold.withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(99)),
                          child: Text(badge,
                              style: const TextStyle(
                                  color: Color(0xFF7A5313),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ],
                  ),
                  Text(subtitle,
                      style: const TextStyle(
                          color: QitafColors.muted, fontSize: 12, height: 1.4)),
                ],
              ),
            ),
            Radio<String>(value: value),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: QitafColors.burgundy),
          const SizedBox(width: 8),
          SizedBox(
              width: 70,
              child: Text(label,
                  style: const TextStyle(color: QitafColors.muted))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }

  void _submit() {
    if (method == 'friend') {
      if (friendPhone.text.trim().length < 7) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('أدخل رقم هاتف الصديق أولًا.')));
        return;
      }
      Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) =>
              FriendPaymentWaitingScreen(phone: friendPhone.text.trim()),
        ),
      );
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => OrderSuccessScreen(method: method)));
  }
}

class FriendPaymentWaitingScreen extends StatefulWidget {
  const FriendPaymentWaitingScreen({super.key, required this.phone});

  final String phone;

  @override
  State<FriendPaymentWaitingScreen> createState() =>
      _FriendPaymentWaitingScreenState();
}

class _FriendPaymentWaitingScreenState
    extends State<FriendPaymentWaitingScreen> {
  int seconds = 30 * 60;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || seconds <= 0) return;
      setState(() => seconds--);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final remainingSeconds = (seconds % 60).toString().padLeft(2, '0');
    final total = AppScope.of(context).total;
    return Scaffold(
      appBar: AppBar(title: const Text('محاكاة دفع الصديق')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 150,
                    height: 150,
                    child: CircularProgressIndicator(
                      value: seconds / (30 * 60),
                      strokeWidth: 9,
                      backgroundColor: QitafColors.sand,
                      color: QitafColors.burgundy,
                    ),
                  ),
                  Column(
                    children: [
                      const Icon(Icons.hourglass_top_rounded,
                          color: QitafColors.burgundy, size: 36),
                      const SizedBox(height: 5),
                      Text('$minutes:$remainingSeconds',
                          style: const TextStyle(
                              fontSize: 25, fontWeight: FontWeight.w900)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 28),
              const Text('معاينة طلب الدفع',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 9),
              Text(
                'لم يُرسل أي رابط إلى ${widget.phone}. هذه شاشة تجريبية توضح المسار فقط، ولا يوجد حجز فعلي للمحصول أو تحويل أموال. مؤقت تجريبي فقط ولا يمثل مهلة حقيقية.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: QitafColors.muted, height: 1.7),
              ),
              const SizedBox(height: 18),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22)),
                child: Column(
                  children: [
                    const Text('المبلغ المعروض في المحاكاة',
                        style: TextStyle(color: QitafColors.muted)),
                    const SizedBox(height: 5),
                    Text('${formatMoney(total)} ريال',
                        style: const TextStyle(
                            color: QitafColors.burgundy,
                            fontSize: 26,
                            fontWeight: FontWeight.w900)),
                    const Divider(height: 28),
                    const Row(
                      children: [
                        Icon(Icons.privacy_tip_outlined,
                            color: QitafColors.terraceGreen),
                        SizedBox(width: 8),
                        Expanded(
                            child: Text(
                                'في الخدمة المستقبلية يجب ألا يظهر عنوان المستلم التفصيلي للصديق الدافع.')),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute<void>(
                      builder: (_) =>
                          const OrderSuccessScreen(method: 'friend')),
                ),
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: const Text('محاكاة: الصديق دفع الآن'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.swap_horiz_rounded),
                label: const Text('اختيار طريقة دفع أخرى'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OrderSuccessScreen extends StatelessWidget {
  const OrderSuccessScreen({super.key, required this.method});

  final String method;

  @override
  Widget build(BuildContext context) {
    final methodLabel = switch (method) {
      'wallet' => 'المحفظة الإلكترونية',
      'friend' => 'محفظة الصديق',
      _ => 'الدفع عند الاستلام',
    };
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 118,
                  height: 118,
                  decoration: const BoxDecoration(
                      color: QitafColors.terraceGreen, shape: BoxShape.circle),
                  child: const Icon(Icons.check_rounded,
                      color: Colors.white, size: 66),
                ),
                const SizedBox(height: 24),
                const Text('تم تأكيد طلبك',
                    style:
                        TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                const SizedBox(height: 9),
                Text(
                  'طريقة الدفع: $methodLabel\nسيظهر للمزارع الآن ليبدأ التجهيز، ويمكنك متابعة الحالة من حسابك.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: QitafColors.muted, height: 1.7),
                ),
                const SizedBox(height: 20),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                  decoration: BoxDecoration(
                      color: QitafColors.sand,
                      borderRadius: BorderRadius.circular(18)),
                  child: const Text('رقم الطلب: QTF-2026-0184',
                      style: TextStyle(
                          fontWeight: FontWeight.w900, letterSpacing: 1)),
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: () {
                    AppScope.of(context).clearCart();
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                  child: const Text('العودة إلى البثوث'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final road = Paint()
      ..color = const Color(0xFFFFFFFF)
      ..strokeWidth = 10
      ..strokeCap = StrokeCap.round;
    final secondary = Paint()
      ..color = const Color(0xFFD0DED2)
      ..strokeWidth = 4;
    canvas.drawLine(Offset(0, size.height * 0.32),
        Offset(size.width, size.height * 0.74), road);
    canvas.drawLine(Offset(size.width * 0.14, 0),
        Offset(size.width * 0.58, size.height), road);
    canvas.drawLine(Offset(0, size.height * 0.78),
        Offset(size.width, size.height * 0.28), secondary);
    for (var i = 0; i < 7; i++) {
      canvas.drawCircle(
          Offset(size.width * (0.1 + i * 0.13),
              size.height * (0.2 + (i % 3) * 0.24)),
          6,
          Paint()..color = const Color(0xFF9ABB9F));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
