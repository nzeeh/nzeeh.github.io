import 'package:flutter/material.dart';

import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';
import '../basket/saved_products_screen.dart';
import '../basket/home_basket_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({
    super.key,
    required this.role,
    required this.onChangeRole,
    required this.onOpenSellerStudio,
  });

  final QitafUserRole role;
  final Future<void> Function() onChangeRole;
  final VoidCallback onOpenSellerStudio;

  @override
  Widget build(BuildContext context) {
    final isSeller = role == QitafUserRole.seller;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 130),
        children: [
          Row(
            children: [
              const QitafWordmark(),
              const Spacer(),
              IconButton.filledTonal(
                onPressed: () {},
                icon: const Icon(Icons.settings_outlined),
              ),
            ],
          ),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isSeller
                    ? const [Color(0xFF174C39), QitafColors.terraceGreen]
                    : const [
                        QitafColors.burgundyDark,
                        QitafColors.burgundy,
                      ],
              ),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.white,
                  child: Icon(
                    isSeller ? Icons.agriculture_rounded : Icons.person_rounded,
                    color: isSeller
                        ? QitafColors.terraceGreen
                        : QitafColors.burgundy,
                    size: 42,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isSeller ? 'مزارع قِطاف' : 'مستخدم قِطاف',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isSeller
                            ? 'صنعاء · حساب بائع تجريبي'
                            : 'صنعاء · حساب مشتري تجريبي',
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          isSeller ? 'بائع / مزارع' : 'مشتري',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.qr_code_rounded,
                    color: Colors.white, size: 32),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      isSeller ? 'طلبات العملاء' : 'طلباتي',
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      'عرض الكل',
                      style: TextStyle(
                        color: QitafColors.burgundy,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: isSeller
                      ? const [
                          _OrderStatus(
                            icon: Icons.notification_important_outlined,
                            label: 'جديدة',
                          ),
                          _OrderStatus(
                            icon: Icons.inventory_2_outlined,
                            label: 'تجهيز',
                          ),
                          _OrderStatus(
                            icon: Icons.local_shipping_outlined,
                            label: 'للسائق',
                          ),
                          _OrderStatus(
                            icon: Icons.payments_outlined,
                            label: 'المستحقات',
                          ),
                        ]
                      : const [
                          _OrderStatus(
                            icon: Icons.schedule_rounded,
                            label: 'بانتظار الدفع',
                          ),
                          _OrderStatus(
                            icon: Icons.inventory_2_outlined,
                            label: 'قيد التجهيز',
                          ),
                          _OrderStatus(
                            icon: Icons.local_shipping_outlined,
                            label: 'في الطريق',
                          ),
                          _OrderStatus(
                            icon: Icons.star_outline_rounded,
                            label: 'للتقييم',
                          ),
                        ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const HomeBasketBanner(),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _quickCard(
                  isSeller
                      ? Icons.inventory_2_outlined
                      : Icons.location_on_outlined,
                  isSeller ? 'منتجاتي' : 'عناويني',
                  isSeller ? 'الأسعار والكميات' : 'البيت وعناوين الهدايا',
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _quickCard(
                  Icons.account_balance_wallet_outlined,
                  isSeller ? 'أرباحي' : 'محفظتي',
                  isSeller ? 'المبيعات والمستحقات' : 'الدفع والاسترجاع',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: [
                _MenuTile(
                  icon: isSeller
                      ? Icons.storefront_outlined
                      : Icons.favorite_border_rounded,
                  title: isSeller ? 'قِطفاتي المحفوظة' : 'قِطفاتي المحفوظة',
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                          builder: (_) => const SavedProductsScreen())),
                ),
                const Divider(height: 1, indent: 58),
                const _MenuTile(
                  icon: Icons.support_agent_rounded,
                  title: 'الدعم وخدمة العملاء',
                ),
                const Divider(height: 1, indent: 58),
                const _MenuTile(
                  icon: Icons.shield_outlined,
                  title: 'الثقة والحماية',
                ),
                const Divider(height: 1, indent: 58),
                const _MenuTile(
                  icon: Icons.language_rounded,
                  title: 'اللغة والدولة والعملة',
                ),
                const Divider(height: 1, indent: 58),
                _MenuTile(
                  icon: Icons.swap_horiz_rounded,
                  title: 'تغيير: بائع أو مشتري',
                  onTap: () => _confirmRoleChange(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onOpenSellerStudio,
              borderRadius: BorderRadius.circular(24),
              child: Ink(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: QitafColors.sand,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 27,
                      backgroundColor: isSeller
                          ? QitafColors.burgundy
                          : QitafColors.terraceGreen,
                      child: Icon(
                        isSeller
                            ? Icons.videocam_rounded
                            : Icons.agriculture_rounded,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isSeller ? 'افتح استوديو العرض' : 'هل أنت مزارع؟',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            isSeller
                                ? 'صوّر محصولك وافتح معاينة بث محلية.'
                                : 'حوّل الوضع وابدأ تصوير عرض تجريبي بالصوت.',
                            style: const TextStyle(color: QitafColors.muted),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmRoleChange(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(
          Icons.swap_horiz_rounded,
          color: QitafColors.burgundy,
          size: 40,
        ),
        title: const Text('تغيير نوع الحساب'),
        content: const Text(
          'ستعود إلى صفحة «هل أنت بائع أم مشتري؟» لاختيار الوضع المناسب.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.55),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('تغيير'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await onChangeRole();
    }
  }

  Widget _quickCard(IconData icon, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: QitafColors.burgundy, size: 29),
          const SizedBox(height: 11),
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
          ),
          Text(
            subtitle,
            maxLines: 2,
            style: const TextStyle(
              color: QitafColors.muted,
              fontSize: 11,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderStatus extends StatelessWidget {
  const _OrderStatus({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 72,
      child: Column(
        children: [
          Icon(icon, color: QitafColors.charcoal, size: 29),
          const SizedBox(height: 7),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.icon,
    required this.title,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: QitafColors.burgundy),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        trailing: const Icon(
          Icons.arrow_back_ios_new_rounded,
          size: 16,
          color: QitafColors.muted,
        ),
      ),
    );
  }
}
