import 'package:flutter/material.dart';
import '../core/theme/qitaf_theme.dart';

String formatMoney(num value) {
  final parts = value.toStringAsFixed(2).split('.');
  final raw = parts.first;
  final buffer = StringBuffer();
  for (var index = 0; index < raw.length; index++) {
    final fromEnd = raw.length - index;
    buffer.write(raw[index]);
    if (fromEnd > 1 && fromEnd % 3 == 1) {
      buffer.write('٬');
    }
  }
  return parts[1] == '00'
      ? buffer.toString()
      : '${buffer.toString()}٫${parts[1]}';
}

String compactCount(int value) {
  if (value >= 1000000) {
    return '${(value / 1000000).toStringAsFixed(1)}م';
  }
  if (value >= 1000) {
    final precision = value >= 10000 ? 0 : 1;
    return '${(value / 1000).toStringAsFixed(precision)}ألف';
  }
  return '$value';
}

class QitafWordmark extends StatelessWidget {
  const QitafWordmark({super.key, this.onDark = false, this.compact = false});

  final bool onDark;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final foreground = onDark ? Colors.white : QitafColors.burgundy;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 32 : 40,
          height: compact ? 32 : 40,
          decoration: BoxDecoration(
            color: onDark
                ? Colors.white.withValues(alpha: 0.16)
                : QitafColors.burgundy,
            borderRadius: BorderRadius.circular(13),
            border:
                Border.all(color: onDark ? Colors.white24 : Colors.transparent),
          ),
          padding: const EdgeInsets.all(6),
          child: Image.asset('assets/icon/qitaf_icon.png'),
        ),
        const SizedBox(width: 9),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'قِطاف',
              style: TextStyle(
                color: foreground,
                fontSize: compact ? 20 : 25,
                height: 1,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (!compact)
              Text(
                'شاهدها من أرضها',
                style: TextStyle(
                  color: onDark ? Colors.white70 : QitafColors.muted,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class LiveChip extends StatelessWidget {
  const LiveChip({super.key, this.label = 'مباشر'});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: QitafColors.live,
        borderRadius: BorderRadius.circular(999),
        boxShadow: const [
          BoxShadow(
              color: Colors.black26, blurRadius: 12, offset: Offset(0, 5)),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.circle, color: Colors.white, size: 8),
          const SizedBox(width: 5),
          Text(label,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  final String title;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w900)),
              if (subtitle != null)
                Text(subtitle!,
                    style:
                        const TextStyle(color: QitafColors.muted, height: 1.5)),
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class ChoicePill extends StatelessWidget {
  const ChoicePill({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: selected ? QitafColors.burgundy : const Color(0xFFF7F1E9),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? QitafColors.burgundy : const Color(0xFFE3D5C5),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : QitafColors.charcoal,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

class QuantityStepper extends StatelessWidget {
  const QuantityStepper({
    super.key,
    required this.value,
    required this.onMinus,
    required this.onPlus,
    this.compact = false,
  });

  final int value;
  final VoidCallback onMinus;
  final VoidCallback onPlus;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final buttonSize = compact ? 34.0 : 42.0;
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFF5EEE4),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _stepButton(Icons.remove, onMinus, buttonSize),
          SizedBox(
            width: compact ? 34 : 46,
            child: Text(
              '$value',
              textAlign: TextAlign.center,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
            ),
          ),
          _stepButton(Icons.add, onPlus, buttonSize),
        ],
      ),
    );
  }

  Widget _stepButton(IconData icon, VoidCallback action, double size) {
    return SizedBox(
      width: size,
      height: size,
      child: IconButton.filled(
        onPressed: action,
        style: IconButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: QitafColors.burgundy,
          padding: EdgeInsets.zero,
        ),
        icon: Icon(icon, size: 19),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.action,
  });

  final IconData icon;
  final String title;
  final String message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(34),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 92,
              height: 92,
              decoration: const BoxDecoration(
                  color: QitafColors.sand, shape: BoxShape.circle),
              child: Icon(icon, size: 44, color: QitafColors.burgundy),
            ),
            const SizedBox(height: 20),
            Text(title,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: QitafColors.muted, height: 1.6),
            ),
            if (action != null) ...[
              const SizedBox(height: 22),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}
