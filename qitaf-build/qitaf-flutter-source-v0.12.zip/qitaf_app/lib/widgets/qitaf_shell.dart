import 'dart:ui';

import 'package:flutter/material.dart';

import '../core/state/app_store.dart';
import '../core/theme/qitaf_theme.dart';
import '../features/cart/cart_screen.dart';
import '../features/farmer/farmer_studio_screen.dart';
import '../features/farmer/seller_home_screen.dart';
import '../features/feed/feed_screen.dart';
import '../features/market/market_screen.dart';
import '../features/profile/profile_screen.dart';

class QitafShell extends StatefulWidget {
  const QitafShell({super.key, required this.role});

  final QitafUserRole role;

  @override
  State<QitafShell> createState() => _QitafShellState();
}

class _QitafShellState extends State<QitafShell> {
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final store = AppScope.of(context);
    final isSeller = widget.role == QitafUserRole.seller;

    final pages = <Widget>[
      if (isSeller)
        SellerHomeScreen(
          onStartStudio: () => _openStudio(context),
          onOpenBuyerFeed: () => _openBuyerFeed(context),
        )
      else
        const FeedScreen(),
      const MarketScreen(),
      CartScreen(onBrowse: () => setState(() => currentIndex = 0)),
      ProfileScreen(
        role: widget.role,
        onChangeRole: store.clearRole,
        onOpenSellerStudio: () => _handleSellAction(context, store),
      ),
    ];

    return Scaffold(
      extendBody: !isSeller && currentIndex == 0,
      body: IndexedStack(index: currentIndex, children: pages),
      bottomNavigationBar: AnimatedBuilder(
        animation: store,
        builder: (context, _) => _QitafBottomBar(
          selectedIndex: currentIndex,
          cartCount: store.cartCount,
          darkMode: !isSeller && currentIndex == 0,
          role: widget.role,
          onSelect: (index) {
            if (index == 2) {
              _handleSellAction(context, store);
              return;
            }
            final mapped = index > 2 ? index - 1 : index;
            setState(() => currentIndex = mapped);
          },
        ),
      ),
    );
  }

  void _openStudio(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const FarmerStudioScreen()),
    );
  }

  Future<void> _handleSellAction(
    BuildContext context,
    AppStore store,
  ) async {
    if (widget.role == QitafUserRole.seller) {
      _openStudio(context);
      return;
    }

    final shouldSwitch = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(
          Icons.agriculture_rounded,
          color: QitafColors.terraceGreen,
          size: 42,
        ),
        title: const Text(
          'هذه الصفحة للبائعين والمزارعين',
          textAlign: TextAlign.center,
        ),
        content: const Text(
          'هل تريد تحويل وضع التطبيق إلى «بائع / مزارع» حتى تتمكن من التصوير والبيع؟',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.55),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('ابقَ مشتريًا'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('تحول إلى بائع'),
          ),
        ],
      ),
    );

    if (shouldSwitch == true) {
      await store.selectRole(QitafUserRole.seller);
    }
  }

  void _openBuyerFeed(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            children: [
              const FeedScreen(),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsetsDirectional.only(
                    top: 54,
                    start: 12,
                  ),
                  child: IconButton.filled(
                    onPressed: () => Navigator.of(context).pop(),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.black45,
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.arrow_forward_rounded),
                    tooltip: 'العودة إلى لوحة البائع',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QitafBottomBar extends StatelessWidget {
  const _QitafBottomBar({
    required this.selectedIndex,
    required this.cartCount,
    required this.darkMode,
    required this.role,
    required this.onSelect,
  });

  final int selectedIndex;
  final int cartCount;
  final bool darkMode;
  final QitafUserRole role;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final displayedSelectedIndex =
        selectedIndex >= 2 ? selectedIndex + 1 : selectedIndex;
    final isSeller = role == QitafUserRole.seller;

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          decoration: BoxDecoration(
            color: darkMode
                ? Colors.black.withValues(alpha: 0.32)
                : Colors.white.withValues(alpha: 0.95),
            border: Border(
              top: BorderSide(
                color: darkMode ? Colors.white12 : Colors.black12,
              ),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(8, 7, 8, 6),
          child: SafeArea(
            top: false,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _item(
                  0,
                  isSeller
                      ? Icons.space_dashboard_rounded
                      : Icons.play_circle_fill_rounded,
                  isSeller ? 'لوحتي' : 'المقاطع',
                  displayedSelectedIndex,
                ),
                _item(
                  1,
                  Icons.storefront_rounded,
                  'السوق',
                  displayedSelectedIndex,
                ),
                _sellButton(isSeller),
                _item(
                  3,
                  Icons.shopping_bag_rounded,
                  'سلتي',
                  displayedSelectedIndex,
                  badge: cartCount,
                ),
                _item(
                  4,
                  Icons.person_rounded,
                  'حسابي',
                  displayedSelectedIndex,
                ),
              ].map<Widget>((child) => Expanded(child: child)).toList(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _item(
    int index,
    IconData icon,
    String label,
    int selected, {
    int badge = 0,
  }) {
    final active = index == selected;
    final inactiveColor = darkMode ? Colors.white70 : QitafColors.muted;
    final activeColor = darkMode ? Colors.white : QitafColors.burgundy;

    return InkWell(
      onTap: () => onSelect(index),
      borderRadius: BorderRadius.circular(18),
      child: SizedBox(
        width: 62,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(
                  icon,
                  color: active ? activeColor : inactiveColor,
                  size: 27,
                ),
                if (badge > 0)
                  PositionedDirectional(
                    top: -7,
                    end: -10,
                    child: Container(
                      constraints: const BoxConstraints(
                        minWidth: 19,
                        minHeight: 19,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: const BoxDecoration(
                        color: QitafColors.live,
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        '$badge',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: active ? activeColor : inactiveColor,
                fontSize: 11,
                fontWeight: active ? FontWeight.w900 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sellButton(bool isSeller) {
    return GestureDetector(
      onTap: () => onSelect(2),
      child: Transform.translate(
        offset: const Offset(0, -12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 62,
              height: 62,
              decoration: BoxDecoration(
                color:
                    isSeller ? QitafColors.burgundy : QitafColors.terraceGreen,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 16,
                    offset: Offset(0, 6),
                  ),
                ],
              ),
              child: Icon(
                isSeller ? Icons.videocam_rounded : Icons.storefront_rounded,
                color: Colors.white,
                size: 32,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              isSeller ? 'صوّر واعرض' : 'وضع البائع',
              style: TextStyle(
                color: darkMode ? Colors.white : QitafColors.burgundy,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
