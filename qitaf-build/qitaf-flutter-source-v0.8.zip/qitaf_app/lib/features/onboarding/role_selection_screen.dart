import 'package:flutter/material.dart';

import '../../core/state/app_store.dart';
import '../../core/theme/qitaf_theme.dart';
import '../../widgets/common_widgets.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> {
  QitafUserRole? pendingRole;

  Future<void> _selectRole(QitafUserRole role) async {
    if (pendingRole != null) {
      return;
    }

    setState(() => pendingRole = role);
    await AppScope.of(context).selectRole(role);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: _RoleBackground()),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
              children: [
                const Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: QitafWordmark(),
                ),
                const SizedBox(height: 30),
                Container(
                  padding: const EdgeInsets.fromLTRB(18, 21, 18, 19),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.91),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: Colors.white),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x1A3E241E),
                        blurRadius: 28,
                        offset: Offset(0, 13),
                      ),
                    ],
                  ),
                  child: const Column(
                    children: [
                      Icon(
                        Icons.touch_app_rounded,
                        color: QitafColors.gold,
                        size: 34,
                      ),
                      SizedBox(height: 9),
                      Text(
                        'هل أنت بائع أم مشتري؟',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: QitafColors.charcoal,
                          fontSize: 27,
                          height: 1.25,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'اضغط على الصورة التي تناسبك. لا توجد خطوات معقدة.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: QitafColors.muted,
                          fontSize: 14,
                          height: 1.55,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                _RoleCard(
                  title: 'أنا مشتري',
                  subtitle: 'أشاهد المزارعين وأشتري المنتج من أرضه.',
                  features: const [
                    'شراء سريع',
                    'توصيل أو هدية',
                    'محفظة أو دفع صديق',
                  ],
                  icon: Icons.shopping_basket_rounded,
                  background: const LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF8B2D3C), Color(0xFF5F1D29)],
                  ),
                  busy: pendingRole == QitafUserRole.buyer,
                  disabled: pendingRole != null,
                  onTap: () => _selectRole(QitafUserRole.buyer),
                ),
                const SizedBox(height: 15),
                _RoleCard(
                  title: 'أنا بائع / مزارع',
                  subtitle: 'أصوّر محصولي وأشرح عنه ثم أبيعه بسهولة.',
                  features: const [
                    'بث مباشر',
                    'السعر داخل الفيديو',
                    'إدارة الطلبات',
                  ],
                  icon: Icons.agriculture_rounded,
                  background: const LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [Color(0xFF2E7659), Color(0xFF174C39)],
                  ),
                  busy: pendingRole == QitafUserRole.seller,
                  disabled: pendingRole != null,
                  onTap: () => _selectRole(QitafUserRole.seller),
                ),
                const SizedBox(height: 19),
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: QitafColors.sand.withValues(alpha: 0.72),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    children: [
                      CircleAvatar(
                        radius: 21,
                        backgroundColor: Colors.white,
                        child: Icon(
                          Icons.swap_horiz_rounded,
                          color: QitafColors.burgundy,
                        ),
                      ),
                      SizedBox(width: 11),
                      Expanded(
                        child: Text(
                          'يمكنك تغيير الاختيار لاحقًا من صفحة «حسابي».',
                          style: TextStyle(
                            color: QitafColors.charcoal,
                            fontWeight: FontWeight.w800,
                            height: 1.45,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.title,
    required this.subtitle,
    required this.features,
    required this.icon,
    required this.background,
    required this.busy,
    required this.disabled,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final List<String> features;
  final IconData icon;
  final Gradient background;
  final bool busy;
  final bool disabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: title,
      hint: subtitle,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(30),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(30),
          child: Ink(
            padding: const EdgeInsets.all(19),
            decoration: BoxDecoration(
              gradient: background,
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x333E241E),
                  blurRadius: 25,
                  offset: Offset(0, 12),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 82,
                  height: 96,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: busy
                      ? const Center(
                          child: SizedBox(
                            width: 29,
                            height: 29,
                            child: CircularProgressIndicator(
                              strokeWidth: 3,
                              color: Colors.white,
                            ),
                          ),
                        )
                      : Icon(icon, color: Colors.white, size: 50),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          height: 1.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 11),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: features
                            .map(
                              (feature) => Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(99),
                                ),
                                child: Text(
                                  feature,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 5),
                const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleBackground extends StatelessWidget {
  const _RoleBackground();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFF3E4), QitafColors.ivory],
        ),
      ),
      child: Stack(
        children: [
          PositionedDirectional(
            top: -90,
            end: -72,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: QitafColors.burgundy.withValues(alpha: 0.09),
              ),
            ),
          ),
          PositionedDirectional(
            top: 145,
            start: -105,
            child: Container(
              width: 235,
              height: 235,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: QitafColors.terraceGreen.withValues(alpha: 0.09),
              ),
            ),
          ),
          PositionedDirectional(
            bottom: -85,
            end: -45,
            child: Container(
              width: 230,
              height: 230,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: QitafColors.gold.withValues(alpha: 0.12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
