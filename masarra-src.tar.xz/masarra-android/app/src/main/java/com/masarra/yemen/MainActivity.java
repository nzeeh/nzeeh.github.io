package com.masarra.yemen;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(255,248,238));getWindow().setNavigationBarColor(Color.rgb(255,248,238));getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);web=new WebView(this);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setMediaPlaybackRequiresUserGesture(false);s.setDefaultTextEncodingName("UTF-8");web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.setBackgroundColor(Color.rgb(255,248,238));setContentView(web);web.loadUrl("file:///android_asset/index.html");}
 private class Bridge { @JavascriptInterface public void theme(String hex){runOnUiThread(()->{try{int c=Color.parseColor(hex);getWindow().setStatusBarColor(c);getWindow().setNavigationBarColor(c);}catch(Exception ignored){}});} }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
